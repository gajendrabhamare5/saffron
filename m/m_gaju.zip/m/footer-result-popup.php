<script>
function view_casiono_result(event_id, casino_type) {
    $(".loader").show();
    $("#cards_data").html("");

    $("#round_no").text(event_id);

    if (casino_type == "teen20") {
        result_title = "20-20 Teenpatti Result";
    } else if (casino_type == "teen") {
        result_title = "1 Day Teenpatti Result";
    } else if (casino_type == "teen9") {
        result_title = "Test Teenpatti Result";
    } else if (casino_type == "war") {
        result_title = "Casino War Result";
    } else if (casino_type == "teen8") {
        result_title = "Open Teenpatti Result";
    } else if (casino_type == "poker") {
        result_title = "1 Day Poker Result";
    } else if (casino_type == "poker20") {
        result_title = "20-20 Poker Result";
    } else if (casino_type == "poker9" || casino_type == "poker6") {
        result_title = "6 Player Poker Result";
    } else if (casino_type == "ab20") {
        //aa baki
        result_title = "Andar Bahar Result";
    } else if (casino_type == "abj") {
        //aa baki
        result_title = "Andar Bahar 2 Result";
    } else if (casino_type == "3cardj") {
        result_title = "3 Card Judgement Result";
    } else if (casino_type == "card32") {
        result_title = "32 Cards - A Result";
    } else if (casino_type == "card32eu") {
        result_title = "32 Cards - B Result";
    } else if (casino_type == "worli") {
        //aa baki
        result_title = "Worli Matka Result";
    } else if (casino_type == "worli2") {
        result_title = "Instant Worli Matka Result";
    } else if (casino_type == "lucky7") {
        result_title = "Lucky 7 - A Result";
    } else if (casino_type == "lucky7eu") {
        result_title = "Lucky 7 - B Result";
    } else if (casino_type == "dt20") {
        result_title = "20-20 Dragon Tiger Result";
    } else if (casino_type == "dt202") {
        result_title = "20-20 Dragon Tiger 2 Result";
    } else if (casino_type == "dt6") {
        result_title = "1-Day Dragon Tiger Result";
    } else if (casino_type == "aaa") {
        result_title = "Amar Akbar Anthony Result";
    } else if (casino_type == "aaa2") {
        result_title = "Amar Akbar Anthony2 Result";
    } else if (casino_type == "btable") {
        result_title = "Bollywood Casino Result";
    } else if (casino_type == "dtl20") {
        result_title = "20-20 Dragon Tiger Lion Result";
    } else if (casino_type == "meter") {
        result_title = "Casino Meter Result";
    } else if (casino_type == "cmatch20") {
        //aa baki
        result_title = "Cricket Casino 20-20 Result";
    } else if (casino_type == "baccarat") {
        result_title = "Baccarat Result";
    } else if (casino_type == "baccarat2") {
        result_title = "Baccarat 2 Result";
    } else if (casino_type == "cmatch20") {
        result_title = "Result";
    } else if (casino_type == "race20") {
        result_title = "Race 20-20 Result";
    } else if (casino_type == "queen") {
        result_title = "Queen Result";
    } else if (casino_type == "cricketv3") {
        result_title = "AUS VS IND 5FIVE CRICKET";
    } else if (casino_type == "superover") {
        result_title = "ENG VS RSA SUPER OVER";
    } else if (casino_type == "ballbyball") {
        result_title = "Ball By Ball";
    } else if (casino_type == "lucky7eu2") {
        result_title = "Lucky 7 - C Result";
    } else if (casino_type == "goal") {
        result_title = "Goal";
    } else if (casino_type == "lucky15") {
        result_title = "Lucky 15";
    } else if (casino_type == "superover3") {
        result_title = "Mini Super Over";
    } else if (casino_type == "superover2") {
        result_title = "Super Over 2";
    } else if (casino_type == "teen41") {
        result_title = "Queen Top Open Teenpatti";
    } else if (casino_type == "teen42") {
        result_title = "Jack Top Open Teenpatti";
    } else if (casino_type == "teen33") {
        result_title = "Instant Teenpatti 3.0";
    } else if (casino_type == "teen3") {
        result_title = "Instant Teenpatti";
    } else if (casino_type == "teen32") {
        result_title = "Instant Teenpatti 2.0";
    } else if (casino_type == "teen6") {
        result_title = "Teenpatti 2.0";
    } else if (casino_type == "sicbo2") {
        result_title = "Sic Bo 2";
    } else if (casino_type == "sicbo") {
        result_title = "Sic Bo";
    } else if (casino_type == "lottcard") {
        result_title = "Lottery";
    } else if (casino_type == "trap") {
        result_title = "The Trap";
    } else if (casino_type == "patti2") {
        result_title = "2 Cards Teenpatti";
    } else if (casino_type == "teensin") {
        result_title = "29Card Baccarat";
    } else if (casino_type == "teenmuf") {
        result_title = " Muflis Teenpatti";
    } else if (casino_type == "race17") {  
        result_title = "Race17";
    } else if (casino_type == "teen20b") {
            result_title = "20-20 Teenpatti B";
        } else if (casino_type == "trio") {
            result_title = "TRIO";
        } else if (casino_type == "notenum") {
            result_title = "Note Number";
        } else if (casino_type == "kbc") {
            result_title = "KBC";
        } else if (casino_type == "teen120") {
            result_title = "1 CARD 20-20";
        } else if (casino_type == "teen1") {
            result_title = "1 CARD ONE-DAY";
        } else if (casino_type == "race2") {
            result_title = "Race to 2nd";
        }
    $("#result_title").text(result_title);
    $.ajax({
        type: 'POST',
        url: '../ajaxfiles/get_result_cards_mobile.php',
        dataType: 'text',
        data: {
            event_id: event_id,
            casino_type: casino_type
        },
        success: function(response) {
            $(".loader").hide();
            $('.casino_result_popup').show();
            $('#casino_result_popup').modal("show");
            $("#cards_data").html(response);
            if (casino_type == "ab20") {
                jQuery("#result-a-cards").owlCarousel({

                    rtl: true,
                    loop: false,
                    margin: 2,
                    nav: true,
                    responsive: {
                        0: {
                            items: 7
                        },

                        600: {
                            items: 7
                        },

                        1000: {
                            items: 7
                        },
                    }
                });
                jQuery("#result-b-cards").owlCarousel({

                    rtl: true,
                    loop: false,
                    margin: 2,
                    nav: true,
                    responsive: {
                        0: {
                            items: 7
                        },

                        600: {
                            items: 7
                        },

                        1000: {
                            items: 7
                        },
                    }
                });
            }
        }
    });
}
</script>
<div id="casino_result_popup" class="modal casino_result_popup" role="dialog">
    <div class="modal-dialog" style="    max-width: 100% !important;">
        <div class="modal-dialog modal-md">
            <div role="document" id="__BVID__28___BV_modal_content_" tabindex="-1" class="modal-content">
                <header id="__BVID__28___BV_modal_header_" class="modal-header">
                    <h5 id="result_title" class="modal-title">Result Details</h5>
                    <button type="button" aria-label="Close" data-dismiss="modal" class="close">&times;</button>
                </header>
                <div id="__BVID__28___BV_modal_body_" class="modal-body">
                    <!---->
                    <!---->
                    <div>
                        <h6 class="text-right round-id"><b>Round Id: </b><span id="round_no">0</span></h6>
                        <div id="cards_data">

                        </div>


                    </div>
                </div>
                <!---->
            </div>
        </div>
    </div>

</div>

<div id="rules_popup" class="modal" role="dialog">
    <div class="modal-dialog rules-modal-dialog" style="max-width: 100% !important;">
        <div class="modal-dialog modal-lg rules-modal-dialog">
            <div role="document" id="__BVID__51___BV_modal_content_" tabindex="-1" class="modal-content rules-modal-content">
                <header id="__BVID__51___BV_modal_header_" class="modal-header">
                    <h5 class="modal-title rules-modal-title" id="Rules">Rules</h5>
                    <button type="button" aria-label="Close" data-dismiss="modal" class="close">&times;</button>
                </header>
                <div id="__BVID__51___BV_modal_body_" class="modal-body rules_popup_image">



                </div>
                <!---->
            </div>
        </div>
    </div>

</div>