<?php
	include("../include/conn.php");
			include('../include/flip_function.php');
	include('../session.php');
	$user_id = $_SESSION['CLIENT_LOGIN_ID'];
		
	$get_parent_ids = $conn->query("select parentSuperMDL from user_login_master where UserID=$user_id");
	$fetch_parent_ids = mysqli_fetch_assoc($get_parent_ids);
	$parentSuperMDL = $fetch_parent_ids['parentSuperMDL'];

	$get_access = $conn->query("select cricket_access,soccer_access,soccer_access,video_access from user_master where Id=$parentSuperMDL");
	$fetch_access = mysqli_fetch_assoc($get_access);
	
	if($fetch_access['video_access'] != 1){
		echo "<script>alert('you are does not access this game');window.location.href='/';</script>";
		exit();
	}
	
?>
<!DOCTYPE html>
<html lang="en">

<?php
	include("head_css2.php");
?>

<style>
    
.casino-table {
    background-color: #f7f7f7;
    color: #333;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 5px;
}

.casino-table {
    background-color: transparent;
}

.roulette-box-container {
  width: 100%;
}
.roulette .clock {
  right: unset;
  left: 0;
  bottom: unset;
  top: 0;
}
.board-in {
  display: grid;
  grid-template-rows: 105fr 50fr;
  grid-template-columns: 44fr 539fr 44fr;
  grid-template-areas:
    "center center right"
    ".      bottom .    ";
  grid-gap: 0.1328125311rem;
  gap: 0.1328125311rem;
  width: 100%;
  position: relative;
  height: 100%;
  pointer-events: none;
}
.board-in {
    grid-template-rows: 28fr 336fr 40fr;
    grid-template-columns: 80fr 206fr;
    grid-template-areas:
    ". center"
    "bottom center"
    ". right ";
    max-width: 80%;
    margin-right: auto;
}
.board-right {
  display: grid;
  grid-area: right;
  grid-template-rows: repeat(3, 1fr);
  grid-gap: 0.1328125311rem;
  gap: 0.1328125311rem;
  pointer-events: all;
}
.board-right {
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: unset;
    gap: 1px;
}
.board-right .board-cell:first-child {
  border-top-right-radius: 1.062500249rem;
}
.board-right .board-cell:last-child {
  border-bottom-right-radius: 1.062500249rem;
}

.board-right .board-cell:first-child {
    order: 1;
}

.board-right .board-cell:first-child {
    border-radius: 0;
}

.board-cell {
  position: relative;
  border-radius: 0.2656250623rem;
  min-height: 50px;
}
.board-cell {
    border-radius: 2px;
    min-height: 35px;
}
.board-right .board-cell:first-child {
    order: 1;
}
.board-cell.active {
  /* border: 3px solid #000; */
  /* filter: contrast(70%); */
}
.board-cell-in {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: inherit;
  transition: background-color 180ms var(--g-ttf);
}
.board-cell-in .rate {
  position: absolute;
  line-height: 14px;
  font-size: 14px;
  bottom: 2px;
}
.board-cell-in::before {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  border-width: 0.1328125311rem;
  border-style: solid;
  border-color: #000;
  border-radius: inherit;
  box-shadow: 0 0 0 4.2500009961rem rgba(var(--g-white-rgb), 0.15) inset;
  opacity: 0;
  pointer-events: none;
  z-index: 0;
}
.board-text,
.board-number {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 26px;
  font-weight: bold;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  pointer-events: none;
  z-index: 1;
}
.board-text, .board-number {
        font-size: 18px;
    }
.board-cell-in .bet-chip-area {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  /* transform: translate3d(-50%, -50%, 0); */
  z-index: 15;
}
.board-bottom {
  display: grid;
  grid-area: bottom;
  grid-template-rows: repeat(2, 1fr);
  grid-template-columns: repeat(6, 1fr);
  grid-template-areas:
    "first      first second second third third      "
    "first-half even  red    black  odd   second-half";
  grid-gap: 0.1328125311rem;
  gap: 0.1328125311rem;
  pointer-events: all;
}
.board-bottom {
        grid-template-rows: repeat(6, 1fr);
        grid-template-columns: repeat(2, 1fr);
        grid-template-areas:
        "first-half first "
        "even first "
        "red second"
        "black second"
        "odd third "
        "second-half third ";
    }
.board-bottom .board-cell:first-child {
  grid-area: first;
}
.board-bottom .board-cell:nth-child(2) {
  grid-area: second;
}
.board-bottom .board-cell:nth-child(3) {
  grid-area: third;
}
.board-bottom .board-cell:nth-child(4) {
  grid-area: first-half;
  border-bottom-left-radius: 1.062500249rem;
}
.board-bottom .board-cell:nth-child(5) {
  grid-area: even;
}
.board-bottom .board-cell:nth-child(6) {
  grid-area: red;
}
.board-bottom .board-cell:nth-child(7) {
  grid-area: black;
}
.board-bottom .board-cell:nth-child(8) {
  grid-area: odd;
}

.board-bottom .board-cell:last-child {
  grid-area: second-half;
  border-bottom-right-radius: 1.062500249rem;
}
.board-center {
  display: grid;
  grid-area: center;
  grid-template-rows: repeat(3, 1fr);
  grid-template-columns: repeat(13, 1fr);
  grid-template-areas:
    "zero c f i l o r u x aa ad ag aj"
    "zero b e h k n q t w z  ac af ai"
    "zero a d g j m p s v y  ab ae ah";
  grid-gap: 0.1328125311rem;
  gap: 0.1328125311rem;
  pointer-events: all;
}
.board-center {
        grid-template-rows: repeat(13, 1fr);
        grid-template-columns: repeat(3, 1fr);
        grid-template-areas:
        "zero zero zero"
        "a b c "
        "d e f "
        "g h i "
        "j k l "
        "m n o "
        "p q r "
        "s t u "
        "v w x "
        "y z aa "
        "ab ac ad "
        "ae af ag "
        "ah ai aj ";
    }
.board-cell.green {
  background-color: #17732e;
  border-radius: 1.062500249rem 0.2656250623rem 0.2656250623rem 1.062500249rem;
}
.board-cell.green.active {
  background-color: #119933;
  box-shadow: 0 0 0 4.2500009961rem rgba(255, 255, 255, 0.15) inset;
}
.board-cell.green {
        border-radius: 8px 8px 2px 2px;
    }
.board-center .board-cell:nth-child(1) {
  grid-area: zero;
}
.board-cell.red {
  background-color: #b2121f;
}
.board-cell.red.active {
  background-color: #e40303;
  box-shadow: 0 0 0 4.2500009961rem rgba(255, 255, 255, 0.15) inset;
}
.board-cell.black {
  background-color: #111111;
}
.board-cell.black.active {
  background-color: #404040;
  box-shadow: 0 0 0 4.2500009961rem rgba(255, 255, 255, 0.15) inset;
}

.board-cell.yellow {
  background-color: #fef0a9;
  color: #b2121f;
}
/* .board-cell.yellow:hover,
.board-cell.yellow:focus,
.board-cell.yellow:active,
.board-cell.yellow.active {
  background-color: yellow;
} */
.board-cell.yellow .board-text,
.board-cell.yellow .borad-number {
  color: red;
}
.board-center .bet-chip-area.center-left {
  top: 50%;
  left: 0;
  width: 50%;
  height: 50%;
  transform: translate3d(-50%, -50%, 0);
  z-index: 20;
}
.board-center .bet-chip-area.bottom-left {
  bottom: 0;
  top: 50%;
  left: 0;
  width: 50%;
  height: 50%;
  transform: translate3d(-50%, 50%, 0);
  z-index: 20;
}
.board-center .bet-chip-area.top-center {
  top: 0;
  left: 50%;
  width: 50%;
  height: 50%;
  transform: translate3d(-50%, -50%, 0);
  z-index: 20;
}
.board-cell-in .bet-chip-area {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  /* transform: translate3d(-50%, -50%, 0); */
  z-index: 15;
  display: flex;
  justify-content: center;
  align-items: center;
}
.board-cell-in .bet-chip-area.coin-place {
  z-index: 14;
}

.board-cell-in .casino-coin {
  width: 35px;
}
.board-cell-in .casino-coin .bet-chip-holder {
  width: 35px;
  height: 35px;
}
.board-cell-in .bet-chip-area img {
  height: 35px;
}
.board-center .board-cell:nth-child(1) {
  grid-area: zero;
}
.board-center .board-cell:nth-child(2) {
  grid-area: a;
}
.board-center .board-cell:nth-child(3) {
  grid-area: b;
}
.board-center .board-cell:nth-child(4) {
  grid-area: c;
}
.board-center .board-cell:nth-child(5) {
  grid-area: d;
}
.board-center .board-cell:nth-child(6) {
  grid-area: e;
}
.board-center .board-cell:nth-child(7) {
  grid-area: f;
}
.board-center .board-cell:nth-child(8) {
  grid-area: g;
}

.board-center .board-cell:nth-child(9) {
  grid-area: h;
}
.board-center .board-cell:nth-child(10) {
  grid-area: i;
}
.board-center .board-cell:nth-child(11) {
  grid-area: j;
}
.board-center .board-cell:nth-child(12) {
  grid-area: k;
}
.board-center .board-cell:nth-child(13) {
  grid-area: l;
}
.board-center .board-cell:nth-child(14) {
  grid-area: m;
}
.board-center .board-cell:nth-child(15) {
  grid-area: n;
}
.board-center .board-cell:nth-child(16) {
  grid-area: o;
}
.board-center .board-cell:nth-child(17) {
  grid-area: p;
}
.board-center .board-cell:nth-child(18) {
  grid-area: q;
}
.board-center .board-cell:nth-child(19) {
  grid-area: r;
}
.board-center .board-cell:nth-child(20) {
  grid-area: s;
}
.board-center .board-cell:nth-child(21) {
  grid-area: t;
}
.board-center .board-cell:nth-child(22) {
  grid-area: u;
}
.board-center .board-cell:nth-child(23) {
  grid-area: v;
}
.board-center .board-cell:nth-child(24) {
  grid-area: w;
}
.board-center .board-cell:nth-child(25) {
  grid-area: x;
}
.board-center .board-cell:nth-child(26) {
  grid-area: y;
}
.board-center .board-cell:nth-child(27) {
  grid-area: z;
}
.board-center .board-cell:nth-child(28) {
  grid-area: aa;
}
.board-center .board-cell:nth-child(29) {
  grid-area: ab;
}
.board-center .board-cell:nth-child(30) {
  grid-area: ac;
}
.board-center .board-cell:nth-child(31) {
  grid-area: ad;
}
.board-center .board-cell:nth-child(32) {
  grid-area: ae;
}
.board-center .board-cell:nth-child(33) {
  grid-area: af;
}
.board-center .board-cell:nth-child(34) {
  grid-area: ag;
}
.board-center .board-cell:nth-child(35) {
  grid-area: ah;
}
.board-center .board-cell:nth-child(36) {
  grid-area: ai;
}
.board-center .board-cell:nth-child(37) {
  grid-area: aj;
}

@media only screen and (min-width: 1200px) and (max-width: 1599px) {
    .board-text, .board-number {
        font-size: 20px;
    }
}

.board-cell-in .rate {
    position: absolute;
    line-height: 14px;
    font-size: 14px;
    bottom: 2px;
}

@media only screen and (min-width: 768px) {
    .board-cell-in .rate {
        font-size: 13px;
    }
}

.board-cell {
    border-radius: 2px;
    min-height: 35px;
}

.board-right .board-cell:last-child {
    order: -1;
    border-radius: 0;
}

.board-bottom {
        grid-template-rows: repeat(6, 1fr);
        grid-template-columns: repeat(2, 1fr);
        grid-template-areas:
        "first-half first "
        "even first "
        "red second"
        "black second"
        "odd third "
        "second-half third ";
    }

    .board-bottom {
        gap: 1;
    }

    .suspended-box {
        position: relative;
        pointer-events: none;
        cursor: none;
    }

    .suspended-box::before {
        background-image: url(storage/front/img/lock.svg);
        background-size: 17px 17px;
        filter: invert(1);
        -webkit-filter: invert(1);
        background-repeat: no-repeat;
        content: "";
        position: absolute;
        z-index: 1;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-position: center;
        pointer-events: none;
    }

    .suspended-box::after {
        content: "";
        background-color: #373636d6;
        position: absolute;
        height: 100%;
        width: 100%;
        left: 0;
        top: 0;
        cursor: not-allowed;
        display: flex;
        justify-content: center;
        align-items: center;
        pointer-events: none;
    }

	.casino-last-results {
		display: flex;
		flex-wrap: wrap;
		justify-content: flex-end;
		margin-top: 10px;
		width: 100%;
	}

	.casino-last-results .result {
		background: #355e3b;
		color: #fff;
		height: 25px;
		width: 25px;
		border-radius: 50%;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		font-weight: bold;
		margin-left: 5px;
		cursor: pointer;
	}

	.casino-last-results .result.result-b {
		color: #ffff33;
	}

	.casino-last-results .result.result-c {
		color: #33c6ff;
	}

	.casino-last-results .result.result-a {
		color: #ff4500;
	}

   .casino-title{
        display: flex;
    }

    .casino-title .d-block{
        margin-top:1px;
    }

    .casino-title a{
        color: #fff;
        text-decoration: underline;
    }

    .board-cell.yellow .board-text {
      top: -7px;
  }

    .board-bottom .board-text {
        transform: rotate(90deg);
    }

        .board-cell-in .rate {
        line-height: 10px;
        font-size: 10px;
        bottom: 4px;
    }

    .board-bottom .board-cell-in .rate {
      transform: rotate(90deg);
      bottom: unset;
      left: 0;
    }
</style>

<body cz-shortcut-listen="true">
    <div id="app">
        <?php
	include ("loader.php");
?>
        <div>
            <?php
				include("header.php");
			?>
            <div class="main-content">
                <!---->
                <!---->
                <div>
                <div class="casino-title"><span class="casino-name">Unique Roulette</span><span class="d-block"><a href="#" onclick="view_rules()" data-target="#rules_popup" data-toggle="modal" id="rules_popup_btn" class="ml-1" role="button">Rules</a></span></div>

<?php
    include("casino_header.php");
?>
                    <div class="tab-content">
                        <div id="bhav" class="tab-pane active">
                            
                            
                            <!---->
                            <div class="casino-video">
                            <iframe id="casinoIframe" src="" width="100%" height="200" style="border: 0px;"></iframe>
                                <!-- <iframe src="<?php echo IFRAME_URL."".OPENTEENPATTI_CODE;?>" width="100%" height="200px" style="border: 0px;"></iframe> -->
                                <div class="clock clock2digit flip-clock-wrapper">
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">2</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">2</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">1</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">1</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="video-overlay">
                                    <div>
                                        <div>
                                            <h3 class="text-white">DEALER</h3>
                                            <div><img id="card8" src="../storage/front/img/cards_new/1.png"> <img id="card17" src="../storage/front/img/cards_new/1.png"> <img id="card26" src="../storage/front/img/cards_new/1.png"></div>
                                        </div>
                                    </div>
                                </div>
								<div class="bet-note theme2bg theme1color specialRemarkdiv" style="display:none;"><span class="greenbx">Result: </span> <span id="specialRemark"></span></div>
                            </div>
                            <div class="casino-detail">
                                <div class="casino-table">
                                    <div class="roulette-box-container">
                                        <div class="board-in">
                                            <div class="board-right">
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">2to1</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="138"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">2to1</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="137"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">2to1</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="136"></div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="board-bottom">
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">1st12</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="133"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">2nd12</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="134"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">3rd12</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="135"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">1 - 18</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="139"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">Even</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="144"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">Red</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="141"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">Black</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="142"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">Odd</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="143"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell yellow ">
                                                <div class="board-cell-in">
                                                    <span class="board-text">19 - 36</span>
                                                    <span class="rate"><b>1.3</b></span>
                                                    <div class="bet-chip-area center-center coin-place" id="140"></div>
                                                </div>
                                                </div>
                                            </div>
                                            <div class="board-center">
                                                <div class="board-cell green ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">0</span>
                                                    <div class="bet-chip-area center-center coin-place" id="1"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">1</span>
                                                    <div class="bet-chip-area center-left coin-place" id="38"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="2"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="110"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="74"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">2</span>
                                                    <div class="bet-chip-area center-left coin-place" id="39"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="3"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="145"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="75"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">3</span>
                                                    <div class="bet-chip-area center-left coin-place" id="40"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="4"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="146"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="98"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">4</span>
                                                    <div class="bet-chip-area center-left coin-place" id="41"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="5"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="76"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">5</span>
                                                    <div class="bet-chip-area center-left coin-place" id="52"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="6"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="111"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="77"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">6</span>
                                                    <div class="bet-chip-area center-left coin-place" id="63"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="7"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="112"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="99"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">7</span>
                                                    <div class="bet-chip-area center-left coin-place" id="42"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="8"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="78"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">8</span>
                                                    <div class="bet-chip-area center-left coin-place" id="53"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="9"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="113"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="79"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">9</span>
                                                    <div class="bet-chip-area center-left coin-place" id="64"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="10"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="114"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="100"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">10</span>
                                                    <div class="bet-chip-area center-left coin-place" id="43"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="11"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="80"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">11</span>
                                                    <div class="bet-chip-area center-left coin-place" id="54"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="12"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="115"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="81"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">12</span>
                                                    <div class="bet-chip-area center-left coin-place" id="65"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="13"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="116"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="101"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">13</span>
                                                    <div class="bet-chip-area center-left coin-place" id="44"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="14"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="82"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">14</span>
                                                    <div class="bet-chip-area center-left coin-place" id="55"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="15"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="117"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="83"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">15</span>
                                                    <div class="bet-chip-area center-left coin-place" id="66"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="16"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="118"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="102"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">16</span>
                                                    <div class="bet-chip-area center-left coin-place" id="45"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="17"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="84"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">17</span>
                                                    <div class="bet-chip-area center-left coin-place" id="56"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="18"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="119"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="85"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">18</span>
                                                    <div class="bet-chip-area center-left coin-place" id="67"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="19"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="120"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="103"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">19</span>
                                                    <div class="bet-chip-area center-left coin-place" id="46"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="20"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="86"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">20</span>
                                                    <div class="bet-chip-area center-left coin-place" id="57"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="21"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="121"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="87"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">21</span>
                                                    <div class="bet-chip-area center-left coin-place" id="68"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="22"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="122"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="104"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">22</span>
                                                    <div class="bet-chip-area center-left coin-place" id="47"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="23"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="88"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">23</span>
                                                    <div class="bet-chip-area center-left coin-place" id="58"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="24"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="123"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="89"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">24</span>
                                                    <div class="bet-chip-area center-left coin-place" id="69"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="25"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="124"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="105"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">25</span>
                                                    <div class="bet-chip-area center-left coin-place" id="48"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="26"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="90"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">26</span>
                                                    <div class="bet-chip-area center-left coin-place" id="59"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="27"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="125"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="91"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">27</span>
                                                    <div class="bet-chip-area center-left coin-place" id="70"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="28"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="126"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="106"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">28</span>
                                                    <div class="bet-chip-area center-left coin-place" id="49"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="29"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="92"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">29</span>
                                                    <div class="bet-chip-area center-left coin-place" id="60"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="30"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="127"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="93"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">30</span>
                                                    <div class="bet-chip-area center-left coin-place" id="71"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="31"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="128"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="107"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">31</span>
                                                    <div class="bet-chip-area center-left coin-place" id="50"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="32"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="94"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">32</span>
                                                    <div class="bet-chip-area center-left coin-place" id="61"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="33"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="129"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="95"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">33</span>
                                                    <div class="bet-chip-area center-left coin-place" id="72"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="34"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="130"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="108"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">34</span>
                                                    <div class="bet-chip-area center-left coin-place" id="51"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="35"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="96"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell black ">
                                                <div class="board-cell-in">
                                                    <span class="board-number">35</span>
                                                    <div class="bet-chip-area center-left coin-place" id="62"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="36"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="131"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="97"></div>
                                                </div>
                                                </div>
                                                <div class="board-cell red">
                                                <div class="board-cell-in">
                                                    <span class="board-number pop-outin">36</span>
                                                    <div class="bet-chip-area center-left coin-place" id="73"></div>
                                                    <div class="bet-chip-area center-center coin-place" id="37"></div>
                                                    <div class="bet-chip-area bottom-left coin-place" id="132"></div>
                                                    <div class="bet-chip-area top-center coin-place" id="109"></div>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="last-result-tiele"><span>Last Result</span> <span class="float-right"><a href="casinoresults?game_type=teen8" class="">View All</a></span></div>
                                <!-- <div class="last-result-container text-right mt-1" id="last-result"></div> -->
                                <div class="casino-last-results"><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-a">A</span></div>
                                <div class="last-result-tiele mt-1"><span>Rules</span></div>
                                <div class="table-responsive rules-table">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="box-10 text-center">Pair Plus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Pair (Double)</td>
                                                <td class="box-3">1 To 1</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Flush (Color)</td>
                                                <td class="box-3">1 To 4</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Straight (Rown)</td>
                                                <td class="box-3">1 To 6</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Trio (Teen)</td>
                                                <td class="box-3">1 To 30</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Straight Flush (Pakki Rown)</td>
                                                <td class="box-3">1 To 40</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                        </div>
                        <?php
							include("open_bet.php");
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>

<script type="text/javascript" src="../js/socket.io.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../storage/front/js/flipclock.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src='footer-js.js'></script>

<script type="text/javascript">
	var site_url = '<?php echo WEB_URL; ?>';
	var websocketurl = '<?php echo GAME_IP; ?>';
	var clock = new FlipClock($(".clock"), {
		clockFace: "Counter"
	});
	var oldGameId = 0;
	var resultGameLast = 0;
	var data6;
	var markettype = "OPENTEENPATTI";
	var markettype_2 = markettype;
	var last_result_id = '0';
	
	function websocket(type) {
		socket = io.connect(websocketurl);
		socket.on('connect', function () {
			socket.emit('Room', 'teen8');
		});
    socket.on('gameIframe', function(data){
            $("#casinoIframe").attr('src',data);
        });
		socket.on('game', function (data) {
			if (data && data['t1'] && data['t1'][0]) {
				if(oldGameId != data.t1[0].mid && data.t1[0].mid != 0 && data.t1[0].mid != "0"){
		  		setTimeout(function(){
						clearCards();
					},<?php echo CASINO_RESULT_TIMEOUT; ?>);
		  	}
				oldGameId = data.t1[0].mid;
				if (data.t1[0].mid != 0 && data.t1[0].mid != "0" && oldGameId != resultGameLast) {
					$(".casino-remark").text(data.t1[0].remark);
					specialRemark = data.t1[0].specialRemark;
					$("#specialRemark").text(specialRemark);
					if (specialRemark == "") {
						$(".specialRemarkdiv").hide();
					}
					else {
						$(".specialRemarkdiv").show();
					}
					data.t1[0].cards = data.t1[0].cards.split(",");
				
					for (var k = 0; k < data.t1[0].cards.length; k++) {
						if (data.t1[0].cards[k] != '1' && data.t1[0].cards[k] != 1) {
							if (k != 8 && k != 17 && k != 26) {
								data6 = getType(data.t1[0].cards[k]);
								if (data6) {
									var cs = data6.card + "<span class='card-" + data6.color + "'>" + data6.type + "</span>";
									$("#card" + k).html(cs);
								}
							}
							else {
								if(k == 26){
								data.t1[0].cards[k] = data.t1[0].cards[k].replace(" ","");
								data.t1[0].cards[k] = data.t1[0].cards[k].replace("#","");
								data.t1[0].cards[k] = data.t1[0].cards[k].replace("2","");
								data.t1[0].cards[k] = data.t1[0].cards[k].replace("1","");
								data.t1[0].cards[k] = data.t1[0].cards[k].replace("Player","");
							}
								$("#card" + k).attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].cards[k] + ".png");
							}
							//$("#card"+k).attr("src",site_url + "storage/front/img/cards_new/" + data.t1[0].cards[k] + ".png");
						}
					}
				}
				clock.setValue(data.t1[0].autotime);
				$(".round_no").text(data.t1[0].mid == 0 ? 0 : typeof data.t1[0].mid=="string" ? data.t1[0].mid.split(".")[1] : data.t1[0].mid);
				eventId = data.t1[0].mid == 0 ? 0 : typeof data.t1[0].mid=="string" ? data.t1[0].mid.split(".")[1] : data.t1[0].mid;
				for (var j in data['t2']) {
					selectionid = parseInt(data['t2'][j].sid);
					runner = data['t2'][j].nat || data['t2'][j].nation;
					b1 = data['t2'][j].rate;
					b1_label = b1;
					if (selectionid == 1) {
						$(".n-bck").html(data['t2'][j].min);
						$(".x-bck").html(data['t2'][j].max);
					}
					if (selectionid > 10) {
						if (selectionid == 11) {
							b1_label = "Pair Plus 1";
							$(".n-pair").html(data['t2'][j].min);
							$(".x-pair").html(data['t2'][j].max);
						}
						else if (selectionid == 12) {
							b1_label = "Pair Plus 2";
						}
						else if (selectionid == 13) {
							b1_label = "Pair Plus 3";
						}
						else if (selectionid == 14) {
							b1_label = "Pair Plus 4";
						}
						else if (selectionid == 15) {
							b1_label = "Pair Plus 5";
						}
						else if (selectionid == 16) {
							b1_label = "Pair Plus 6";
						}
						else if (selectionid == 17) {
							b1_label = "Pair Plus 7";
						}
						else if (selectionid == 18) {
							b1_label = "Pair Plus 8";
						}
					}
					markettype = "OPENTEENPATTI";
					var value1 = $('.market_' + selectionid + '_b_exposure').html();
					var color1 = parseInt(value1) > 0 ? 'green' : 'black';
					back_html = '<span  class="odd d-block">' + b1_label + '</span> <span  class="market_' + selectionid + '_b_exposure market_exposure" style="color: '+color1+';">'+value1+'</span>';
					$(".market_" + selectionid + "_b_btn").attr("side", "Back");
					$(".market_" + selectionid + "_b_btn").attr("selectionid", selectionid);
					$(".market_" + selectionid + "_b_btn").attr("marketid", selectionid);
					$(".market_" + selectionid + "_b_btn").attr("runner", runner);
					$(".market_" + selectionid + "_b_btn").attr("marketname", runner);
					$(".market_" + selectionid + "_b_btn").attr("eventid", eventId);
					$(".market_" + selectionid + "_b_btn").attr("markettype", markettype);
					$(".market_" + selectionid + "_b_btn").attr("event_name", markettype);
					$(".market_" + selectionid + "_b_btn").attr("fullmarketodds", b1);
					$(".market_" + selectionid + "_b_btn").attr("fullfancymarketrate", b1);
					$(".market_" + selectionid + "_b_btn").html(back_html);
					gstatus = data['t2'][j].gstatus.toString();
					if (gstatus == "SUSPENDED" || gstatus == "0") {
						$(".market_" + selectionid + "_row").addClass("suspended");
					}
					else {
						$(".market_" + selectionid + "_row").removeClass("suspended");
					}
				}
			}
		});
		socket.on('gameResult', function (args) {
			if(args.data){
				updateResult(args.data);
			}else{
				updateResult(args['res']);
			}
		});
		socket.on('error', function (data) {});
		socket.on('close', function (data) {});
	}

	function getType(data) {
		var data1 = data;
		if (data) {
			data = data.split('DD');
			if (data.length > 1) {
				var obj = {
					type: '[',
					color: 'red',
					card: data[0]
				}
				return obj;
			}
			else {
				data = data1;
				data = data.split('HH');
				if (data.length > 1) {
					var obj = {
						type: '{',
						color: 'red',
						card: data[0]
					}
					return obj;
				}
				else {
					data = data1;
					data = data.split('SS');
					if (data.length > 1) {
						var obj = {
							type: '}',
							color: 'black',
							card: data[0]
						}
						return obj;
					}
					else {
						data = data1;
						data = data.split('CC');
						if (data.length > 1) {
							var obj = {
								type: ']',
								color: 'black',
								card: data[0]
							}
							return obj;
						}
						else {
							return 0;
						}
					}
				}
			}
		}
		return 0;
	}

	function clearCards() {
		refresh(markettype);
		$("#card0").html('');
		$("#card1").html('');
		$("#card2").html('');
		$("#card3").html('');
		$("#card4").html('');
		$("#card5").html('');
		$("#card6").html('');
		$("#card7").html('');
		$("#card8").attr("src", site_url + "storage/front/img/cards_new/1.png");
		$("#card9").html('');
		$("#card10").html('');
		$("#card11").html('');
		$("#card12").html('');
		$("#card13").html('');
		$("#card14").html('');
		$("#card15").html('');
		$("#card16").html('');
		$("#card17").attr("src", site_url + "storage/front/img/cards_new/1.png");
		$("#card18").html('');
		$("#card19").html('');
		$("#card20").html('');
		$("#card21").html('');
		$("#card22").html('');
		$("#card23").html('');
		$("#card24").html('');
		$("#card25").html('');
		$("#card26").attr("src", site_url + "storage/front/img/cards_new/1.png");
	}

	function updateResult(data) {
	
		if (data && data[0]) {
			resultGameLast = data[0].mid;

			if(last_result_id != resultGameLast){
				last_result_id = resultGameLast;
				
			}
		
			html = "";
			var ab = "";
			var ab1 = "";
			casino_type = "'teen8'";
			data.forEach((runData) => {
				if (parseInt(runData.result) == 11) {
					ab = "playera";
					ab1 = "R";

				}
				else if (parseInt(runData.result) == 21) {
					ab = "playerb";
					ab1 = "R";

				}
				else {
					ab = "playerc";
					ab1 = "R";
				}

				eventId = runData.mid == 0 ? 0 : typeof runData.mid == "string" ? runData.mid.split(".")[1] : runData.mid;
				html += '<span onclick="view_casiono_result(' + eventId + ',' + casino_type + ')"  class="ball-runs  ' + ab + ' last-result">' + ab1 + '</span>';
			});
			$("#last-result").html(html);
			if (oldGameId == 0 || oldGameId == resultGameLast) {
				$("#card_c1").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c2").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c3").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c4").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c5").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c6").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c7").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c8").attr("src", site_url + "storage/front/img/cards_new/1.png");
				$("#card_c9").attr("src", site_url + "storage/front/img/cards_new/1.png");
			}
		}
	}

	function teenpatti(type) {
		gameType = type
		websocket();
	}

	teenpatti("ok");
	jQuery(document).on("click", ".back-1", function () {
		var fullmarketodds = $(this).attr("fullmarketodds");
		if (fullmarketodds != "") {
			side = $(this).attr("side");
			selectionid = $(this).attr("selectionid");
			market_odd_name = $(this).attr("markettype");
			runner = $(this).attr("runner");
			market_runner_name = runner;
			marketname = $(this).attr("marketname");
			markettype = $(this).attr("markettype");
			fullfancymarketrate = $(this).attr("fullfancymarketrate");
			odds_change_value = "disabled";
			runs_lable = 'Runs';
			runs_lable = 'Odds';
			fullfancymarketrate = fullmarketodds;
			eventId = $(this).attr("eventid");
			marketId = $(this).attr("marketid");
			event_name = $(this).attr("event_name");
			$(".select").removeClass("select");
			$(this).addClass("select");
			return_html = "";

			$("#inputStake").val();
			$("#market_runner_label").text(market_runner_name);
			$("#bet_stake_side").val("Back");
			$("#odds_val").val(fullmarketodds);
			$("#bet_event_id").val(eventId);
			$("#bet_marketId").val(marketId);
			$("#bet_event_name").val(event_name);
			$("#bet_market_name").val(marketname);
			$("#bet_markettype").val(markettype);
			$("#fullfancymarketrate").val(fullfancymarketrate);
			$("#oddsmarketId").val(marketId);
			$("#market_runner_name").val(market_runner_name);
			$("#market_odd_name").val(market_odd_name);
			
			$('#profitLiability').text('0');
			$(".placeBet").attr('disabled',false);
			$("#inputStake").val("0");
			
			$('.open_back_place_bet').show();
			$('#open_back_place_bet').modal("show");
		}
	});

	jQuery(document).on("input", "#inputStake", function () {
		var stake = $("#inputStake").val();
		eventId = $("#fullMarketBetsWrap").attr("eventid");
		$("#inputStake").val(stake);
		odds = parseFloat($("#odds_val").val());
		inputStake = $("#inputStake").val();
		bet_stake_side = $("#bet_stake_side").val();
		bet_markettype = $("#bet_markettype").val();
		if (bet_markettype != "FANCY_ODDS") {
			if (bet_stake_side == "Lay") {
				profit = parseInt(inputStake);
			}
			else {
				profit = (odds - 1) * inputStake;
			}
		}
		$("#profitLiability").text(profit.toFixed(2));
	});
	jQuery(document).on("click", ".label_stake", function () {
		stake = $(this).attr("stake");
		eventId = $("#fullMarketBetsWrap").attr("eventid");
		$("#inputStake").val(stake);
		odds = parseFloat($("#odds_val").val());
		inputStake = $("#inputStake").val();
		bet_stake_side = $("#bet_stake_side").val();
		bet_markettype = $("#bet_markettype").val();
		if (bet_markettype != "FANCY_ODDS") {
			if (bet_stake_side == "Lay") {
				profit = (odds - 1) * inputStake;
			}
			else {
				profit = (odds - 1) * inputStake;
			}
		}
		$("#profitLiability").text(profit.toFixed(2));
	});

	jQuery(document).on("click", "#placeBet", function () {

		$("#placeBet").html('<i class="fa fa-spinner  fa-spin"></i> Submit');
		$(".placeBet").attr('disabled',true);
		$(".placeBet").removeAttr("id", "placeBet");
		var last_place_bet = "";
		bet_stake_side = $("#bet_stake_side").val();
		bet_event_id = $("#bet_event_id").val();
		bet_marketId = $("#bet_marketId").val();
		oddsmarketId = bet_marketId;
		eventType = 'OPENTEENPATTI';
		bet_event_name = $("#bet_event_name").val();
		inputStake = $("#inputStake").val();
		market_runner_name = $("#market_runner_name").val();
		market_odd_name = $("#market_odd_name").val();
		var runsNo;
		var oddsNo;
		bet_market_name = $("#bet_market_name").val();
		eventManualType = 'Auto';
		if (bet_stake_side == "Lay") {
			type = "No";
			class_type = "no";
			unmatched_side_type = false;
		}
		else {
			type = "Yes";
			class_type = "yes";
			unmatched_side_type = true;
		}
		bet_markettype = $("#bet_markettype").val();
		if (bet_markettype != "FANCY_ODDS") {
			bet_market_type = bet_markettype;
			runsNo = parseFloat($("#odds_val").val());
			oddsNo = parseFloat($("#odds_val").val());
			if (bet_stake_side == "Lay") {
				return_stake = (oddsNo - 1) * inputStake;
				return_stake = parseInt(return_stake);
			}
			else {
				return_stake = (oddsNo - 1) * inputStake;
				return_stake = parseInt(return_stake);
			}
			bet_seconds = 1;
			bet_sec = 1000;
		}
		
		/* $("#inputStake").val(""); */
		$(".back-1").removeClass("select");
		$(".lay-1").removeClass("select");
		$("#loadingMsg").show();
		$('.header_Back_' + bet_event_id).remove();
		$('.header_Lay_' + bet_event_id).remove();
		$('#betSlipFullBtn').hide();
		$('#backSlipHeader').hide();
		$('#laySlipHeader').hide();
		$(".back-1").removeClass("select");
		$(".lay-1").removeClass("select");
		
		$("#bet-error-class").removeClass("b-toast-danger");
		$("#bet-error-class").removeClass("b-toast-success");
		setTimeout(function () {
			$.ajax({
				type: 'POST',
				url: '../ajaxfiles/bet_place_open_teenpatti.php',
				dataType: 'json',
				data: {
					eventId: bet_event_id,
					eventType: eventType,
					marketId: bet_marketId,
					stack: inputStake,
					type: type,
					odds: oddsNo,
					runs: runsNo,
					bet_market_type: bet_market_type,
					oddsmarketId: oddsmarketId,
					eventManualType: eventManualType,
					market_runner_name: market_runner_name,
					market_odd_name: market_odd_name,
					bet_event_name: bet_event_name
				},
				success: function (response) {
					var check_status = response['status'];
					var message = response['message'];
					if (check_status == 'ok') {
						if (bet_markettype != "FANCY_ODDS") {
							oddsNo = runsNo;
						}
						else {
							oddsNo = oddsNo;
						}
						auth_key = 1;
						$("#bet-error-class").addClass("b-toast-success");
					}
					else {
						$("#bet-error-class").addClass("b-toast-danger");
					}
					error_message_text = message;
					$("#errorMsgText").text(error_message_text);
					$("#errorMsg").fadeIn('fast').delay(3000).hide(0);
					$(".close-bet-slip").click();
					refresh(markettype);
					$(".placeBet").attr("id", "placeBet");
					$("#placeBet").html('Submit');
					$(".placeBet").attr('disabled',false);
					$('.open_back_place_bet').hide();
					$('#open_back_place_bet').modal("hide");
				}
			});
		}, bet_sec - 2000);
	});
</script>  
<div id="open_back_place_bet" class="modal open_back_place_bet" role="dialog" >
   <div class="modal-dialog">
      <div role="document" id="__BVID__30___BV_modal_content_" tabindex="-1" class="modal-content">
         <header id="__BVID__30___BV_modal_header_" class="modal-header">
            <h5 id="__BVID__30___BV_modal_title_" class="modal-title">Placebet</h5>
            <button type="button" data-dismiss="modal" class="close">&times;</button>                
         </header>
         <div id="__BVID__30___BV_modal_body_" class="modal-body" style="    padding: 0px;">
            <div class="place-bet pt-2 pb-2 back">
               <div class="container-fluid container-fluid-5">
                  <div class="row row5">
                     <div class="col-5"><b id="market_runner_label">Player A</b></div>
                     <div class="col-7 text-right">
                        <div class="float-right">                                        
                        <button class="stakeactionminus btn disabled">
                        	<span class="fa fa-minus"></span>
                        </button>                                        
                        <input type="text" placeholder="0" class="stakeinput" id="odds_val">                                        
                        	<button class="stakeactionminus btn disabled">
                        		<span class="fa fa-plus"></span>
                        	</button>                    
<input type='hidden' id='bet_stake_side' value=''/><input type='hidden' id='bet_event_id' value=''/><input type='hidden' id='bet_marketId' value=''/><input type='hidden' id='bet_event_name' value=''/><input type='hidden' id='bet_market_name' value=''/><input type='hidden' id='bet_markettype' value=''/><input type='hidden' id='fullfancymarketrate' value=''/> <input type='hidden' id='oddsmarketId' value=''/><input type='hidden' id='market_runner_name' value=''/><input type='hidden' id='market_odd_name' value=''/> 
							</div>
                     </div>
                  </div>
                  <div class="row row5 mt-2">
                     <div class="col-4">                                    
                     	<input type="number" placeholder="00" id="inputStake" class="stakeinput w-100">                                
                     </div>
                     <div class="col-4">
                        <button class="btn btn-primary btn-block  placeBet" id="placeBet">
                           <!---->Submit                                    
                        </button>
                     </div>
                     <div class="col-4 text-center pt-1"><span id="profitLiability">0</span></div>
                  </div>
                  <div class="row row5 mt-2">
                     <?php										
                     	$get_button_value = $conn->query("select * from user_master where id=$user_id and (button_value <> '' and button_value IS NOT NULL)");					
                     	$num_rows = $get_button_value->num_rows;					
                     	$button_array = array();					
                     	if($num_rows <= 0){						
                     		$button_array[] = 500;						
                     		$button_array[] = 1000;						
                     		$button_array[] = 2000;						
                     		$button_array[] = 3000;						
                     		$button_array[] = 4000;						
                     		$button_array[] = 5000;						
                     		$button_array[] = 10000;						
                     		$button_array[] = 20000;					
                     	}else{						
                     		$fetch_button_value_data = mysqli_fetch_assoc($get_button_value);						
                     		$fetch_button_value = $fetch_button_value_data['button_value'];						
                     		$default_stake = $fetch_button_value_data['default_stake'];						
                     		$one_bet_default_stake = $fetch_button_value_data['one_bet_default_stake'];						
                     		$button_array = explode(",",$fetch_button_value);					}										
                     		foreach($button_array as $button_value){				
                     ?>														
                    	 		<div class="col-4">                                   
                    	 			<button type="button" class="btn btn-secondary btn-block mb-2 label_stake" stake='<?php echo $button_value; ?>'>                                       
                    	 				<?php echo $button_value; ?>                                    
                    	 			</button>                                
                    	 		</div>
                     <?php					
                     		}				
                     ?>								                                                            
                  </div>
               </div>
            </div>
         </div>
         <!---->            
      </div>
   </div>
</div>
<div id="errorMsg" class="b-toaster b-toaster-top-center" style="display:none;">
<div class="b-toaster-slot vue-portal-target">
    <div role="alert" aria-live="assertive" aria-atomic="true" id="bet-error-class" class="b-toast b-toast-solid b-toast-prepend b-toast-danger">
        <div tabindex="0"  class="toast">
            <header class="toast-header"><strong class="mr-2" id="errorMsgText"></strong>
                
            </header>
            <div class="toast-body"> </div>
        </div>
    </div>
</div>
</div>
<?php
	include "footer.php";
	include "footer-result-popup.php";
?>
</html>