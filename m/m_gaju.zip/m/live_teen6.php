<?php
include("../include/conn.php");
include('../include/flip_function.php');
include('../session.php');
$user_id = $_SESSION['CLIENT_LOGIN_ID'];

$get_parent_ids = $conn->query("select parentSuperMDL from user_login_master where UserID=$user_id");
$fetch_parent_ids = mysqli_fetch_assoc($get_parent_ids);
$parentSuperMDL = $fetch_parent_ids['parentSuperMDL'];

$get_access = $conn->query("select cricket_access,soccer_access,soccer_access,video_access from user_master where Id=$parentSuperMDL");
$fetch_access = mysqli_fetch_assoc($get_access);

if ($fetch_access['video_access'] != 1) {
    echo "<script>alert('you are does not access this game');window.location.href='/';</script>";
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<?php
include("head_css2.php");
?>
<style>
.casino-table {
    background-color: #f7f7f7;
    color: #333;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 5px;
}

.casino-table-box {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: flex-start;
}


.casino-table-left-box,
.casino-table-center-box,
.casino-table-right-box {
    width: 49%;
    border-left: 1px solid #c7c8ca;
    border-right: 1px solid #c7c8ca;
    border-top: 1px solid #c7c8ca;
    background-color: #f2f2f2;
}

.casino-table-header,
.casino-table-row {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    border-bottom: 1px solid #c7c8ca;
}

.teenpatti2 .casino-nation-detail {
    width: 60%;
}

.casino-table-header .casino-nation-detail {
    font-weight: bold;
    min-height: unset;
}

.casino-nation-detail {
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    flex-wrap: wrap;
    justify-content: center;
    padding-left: 5px;
    min-height: 46px;
}

.teenpatti2 .casino-odds-box {
    width: 20%;
}

.casino-table-header .casino-odds-box {
    cursor: unset;
    padding: 2px;
    min-height: unset;
    height: auto !important;
}

.casino-odds-box {
    display: flex;
    flex-wrap: wrap;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 5px 0;
    font-weight: bold;
    border-left: 1px solid #c7c8ca;
    cursor: pointer;
    min-height: 46px;
}

.casino-nation-name {
    font-size: 16px;
    font-weight: bold;
}

.suspended-box {
    position: relative;
    pointer-events: none;
    cursor: none;
}

.suspended-box::before {
    background-image: url(../storage/front/img/lock.svg);
    background-size: 17px 17px;
    filter: invert(1);
    -webkit-filter: invert(1);
    background-repeat: no-repeat;
    content: "";
    position: absolute;
    z-index: 1;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-position: center;
    pointer-events: none;
}

.casino-odds {
    font-size: 18px;
    font-weight: bold;
    line-height: 1;
}

.suspended-box::after {
    content: "";
    background-color: #373636d6;
    position: absolute;
    height: 100%;
    width: 100%;
    left: 0;
    top: 0;
    cursor: not-allowed;
    display: flex;
    justify-content: center;
    align-items: center;
    pointer-events: none;
}

.under-over-row .uo-box {
    display: flex;
    flex-wrap: wrap;
    width: 48%;
    margin-top: 10px;
    border: 1px solid #c7c8ca;
}

.teenpatti2 .under-over-row .uo-box .casino-nation-detail {
    width: 70%;
}

.teenpatti2 .under-over-row .uo-box .casino-odds-box {
    width: 30%;
}

.teenpatti2 .teen2other {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    border: 0;
}

.casino-table-full-box {
    /* width: 100%;
    border-left: 1px solid var(--table-border);
    border-right: 1px solid var(--table-border);
    border-top: 1px solid var(--table-border);
    background-color: var(--bg-table-row); */
}

.teenpatti2 .teen2other .casino-odds-box {
    width: 16%;
    flex-direction: row;
    justify-content: space-between;
    padding: 5px 10px;
}

.bltitle img {
    height: 35px;
}

.teen2cards {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    border: 0;
    padding: 10px 10px 0 10px;
}

.card-odd-box {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    flex-direction: column;
    align-items: center;
    margin-bottom: 10px;
    margin-right: 10px;
    cursor: pointer;
}

.card-odd-box .casino-odds {
    margin-bottom: 5px;
    font-size: 14px;
}

.card-odd-box img {
    height: 75px;
}

@media only screen and (min-width: 1200px) and (max-width: 1399px) {
    .card-odd-box img {
        height: 45px;
    }
}

@media only screen and (max-width: 767px) {
    .casino-table-box {
        padding: 5px;
    }

    .casino-table-left-box,
    .casino-table-right-box {
        width: 100%;
        padding: 0 5px;
    }

    .teenpatti2 .teen2other .casino-odds-box {
        width: 49%;
        margin-bottom: 10px;
    }

    .teenpatti2 .casino-table-right-box {
        margin-top: 10px;
    }

    .card-odd-box img {
        height: 45px;
    }

}

.casino-table-box-divider {
    background-color: var(--table-border);
    width: 2px;
}
</style>

<body cz-shortcut-listen="true">
    <div id="app">
        <?php
        include("loader.php");
        ?>
        <div>
            <?php
            include("header.php");
            ?>
            <div class="main-content">
                <!---->
                <!---->
                <div>
                <div class="casino-title"><span class="casino-name">Teenpatti - 2.0</span>
                            </div>
                    <?php
                    include("casino_header.php");
                    ?>
                    <div class="tab-content">
                        <div id="bhav" class="tab-pane active">
                            
                            <!---->
                            <div class="casino-video">
							<iframe id="casinoIframe" src="" width="100%" height="200" style="border: 0px;"></iframe>
                                <!--<iframe src="<?php echo IFRAME_URL;
                                                echo TEEN6_CODE; ?>" width="100%" height="200"
                                    style="border: 0px;"></iframe>-->
                                <div class="clock clock2digit flip-clock-wrapper">
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">4</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">4</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">3</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">3</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">6</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">6</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">5</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">5</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="video-overlay">
                                    <div>
                                        <div>
                                            <h3 class="text-white">PLAYER A</h3>
                                            <div>
                                                <img id="card_c1" src="../storage/mobile/img/cards/1.png">
                                                <img id="card_c2" src="../storage/mobile/img/cards/1.png">
                                                <img id="card_c3" src="../storage/mobile/img/cards/1.png">
                                            </div>
                                        </div>
                                        <div>
                                            <h3 class="text-white">PLAYER B</h3>
                                            <div>
                                                <img id="card_c4" src="../storage/mobile/img/cards/1.png">
                                                <img id="card_c5" src="../storage/mobile/img/cards/1.png">
                                                <img id="card_c6" src="../storage/mobile/img/cards/1.png">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="casino-container teenpatti-1day">
                                <div class="casino-table teenpatti2">
                                    <div class="casino-table-box">
                                        <div class="casino-table-left-box">
                                            <div class="casino-table-header">
                                                <div class="casino-nation-detail">Player A</div>
                                                <div class="casino-odds-box back">Back</div>
                                                <div class="casino-odds-box lay">Lay</div>
                                            </div>
                                            <div class="casino-table-body">
                                                <div class="casino-table-row ">
                                                    <div class="casino-nation-detail">
                                                        <div class="casino-nation-name">Main</div>
                                                    </div>
                                                    <div class="casino-odds-box back back-1 market_1_b_btn"><span
                                                            class="casino-odds">1.56</span></div>
                                                    <div class="casino-odds-box lay lay-1 market_1_l_btn"><span
                                                            class="casino-odds">1.61</span></div>
                                                </div>
                                                <div class="casino-table-row under-over-row">
                                                    <div class="uo-box">
                                                        <div class="casino-nation-detail">
                                                            <div class="casino-nation-name">Under 21</div>
                                                        </div>
                                                        <div class="casino-odds-box back back-1 market_9_b_btn"><span
                                                                class="casino-odds">0</span></div>
                                                    </div>
                                                    <div class="uo-box">
                                                        <div class="casino-nation-detail">
                                                            <div class="casino-nation-name">Over 22</div>
                                                        </div>
                                                        <div class="casino-odds-box back back-1 market_10_b_btn"><span
                                                                class="casino-odds">0</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="casino-table-box-divider"></div>
                                        <div class="casino-table-right-box">
                                            <div class="casino-table-header">
                                                <div class="casino-nation-detail">Player B</div>
                                                <div class="casino-odds-box back">Back</div>
                                                <div class="casino-odds-box lay">Lay</div>
                                            </div>
                                            <div class="casino-table-body">
                                                <div class="casino-table-row">
                                                    <div class="casino-nation-detail">
                                                        <div class="casino-nation-name">Main</div>
                                                    </div>
                                                    <div
                                                        class="casino-odds-box back back-1 market_2_b_btn suspended-box">
                                                        <span class="casino-odds">0</span></div>
                                                    <div class="casino-odds-box lay lay-1 market_2_l_btn suspended-box">
                                                        <span class="casino-odds">0</span></div>
                                                </div>
                                                <div class="casino-table-row under-over-row">
                                                    <div class="uo-box">
                                                        <div class="casino-nation-detail">
                                                            <div class="casino-nation-name">Under 21</div>
                                                        </div>
                                                        <div
                                                            class="casino-odds-box back suspended-box back-1 market_11_b_btn">
                                                            <span class="casino-odds">0</span></div>
                                                    </div>
                                                    <div class="uo-box">
                                                        <div class="casino-nation-detail">
                                                            <div class="casino-nation-name">Over 22</div>
                                                        </div>
                                                        <div
                                                            class="casino-odds-box back back-1 market_12_b_btn suspended-box">
                                                            <span class="casino-odds">0</span></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-100 other_markets mt-3">
                                    </div>
                                    <!-- <div class="w-100 teen2other mt-3">
                                        <div class="casino-odds-box back  suspended-box">
                                            <div class="bltitle"><img src="../storage/front/img/cards/spade_race.png"></div>
                                            <div><span class="casino-odds">4.09</span></div>
                                        </div>
                                        <div class="casino-odds-box back  suspended-box">
                                            <div class="bltitle"><img src="../storage/front/img/cards/heart_race.png"></div>
                                            <div><span class="casino-odds">3.78</span></div>
                                        </div>
                                        <div class="casino-odds-box back">
                                            <div class="bltitle"><img src="../storage/front/img/cards/club_race.png"></div>
                                            <div><span class="casino-odds">3.78</span></div>
                                        </div>
                                        <div class="casino-odds-box back">
                                            <div class="bltitle"><img src="../storage/front/img/cards/diamond_race.png"></div>
                                            <div><span class="casino-odds">3.78</span></div>
                                        </div>
                                        <div class="casino-odds-box back">
                                            <div><b>Odd</b></div>
                                            <div><span class="casino-odds">1.86</span></div>
                                        </div>
                                        <div class="casino-odds-box back">
                                            <div><b>Even</b></div>
                                            <div><span class="casino-odds">2.09</span></div>
                                        </div>
                                    </div>
                                    <div class="w-100 casino-table-full-box teen2cards mt-3">
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/1.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/2.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/3.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/4.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/5.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/6.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/7.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/8.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/9.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/10.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/11.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">11.81</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/12.jpg"></div>
                                        </div>
                                        <div class="card-odd-box"><span class="casino-odds">15.72</span>
                                            <div class=""><img src="../storage/front/img/andar_bahar/13.jpg"></div>
                                        </div>
                                    </div> -->
                                </div>
                                <div class="last-result-tiele"><span>Last Result</span> <span class="float-right"><a
                                            href="casinoresults?game_type=teen6" class="">View All</a></span></div>
                                <div id="last-result" class="last-result-container text-right mt-1"></div>
                                <!---->
                                <!---->
                                <!---->
                            </div>
                        </div>
                        <?php
                        include("open_bet.php");
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

<script type="text/javascript" src="../js/socket.io.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../storage/front/js/flipclock.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src='footer-js.js'></script>

<script type="text/javascript">
var site_url = '<?php echo WEB_URL; ?>';
var websocketurl = '<?php echo GAME_IP; ?>';
var clock = new FlipClock($(".clock"), {
    clockFace: "Counter"
});
var oldGameId = 0;
var resultGameLast = 0;
var selectionid = "";
var runner = "";
var b1 = "";
var bs1 = "";
var l1 = "";
var ls1 = "";
var markettype = "TEEN6";
var markettype_2 = markettype;
var back_html = "";
var lay_html = "";
var gstatus = "";
var last_result_id = '0';

function websocket(type) {
    socket = io.connect(websocketurl);
    socket.on('connect', function() {
        socket.emit('Room', 'teen6');
    });
	socket.on('gameIframe', function(data){
    	$("#casinoIframe").attr('src',data);
    });
    socket.on('game', function(data) {
		console.log("data=",data);
        data1 = data;
        if (data) {
            if (oldGameId != data1.t1[0].mid && data1.t1[0].mid != 0 && data1.t1[0].mid != "0") {
                setTimeout(function() {
                    clearCards();
                }, <?php echo CASINO_RESULT_TIMEOUT; ?>);
            }
            oldGameId = data1.t1[0].mid;
            if (data1.t1[0].mid != 0 && data1.t1[0].mid != "0" && oldGameId != resultGameLast) {
                $(".casino-remark")
                    .text(data.t1[0].remark);
                if (data.t1[0].C1 != 1) {
                    $("#card_c1").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C1 +
                        ".png");
                }
                if (data.t1[0].C2 != 1) {
                    $("#card_c4").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C2 +
                        ".png");
                }
                if (data.t1[0].C3 != 1) {
                    $("#card_c2").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C3 +
                        ".png");
                }
                if (data.t1[0].C4 != 1) {
                    $("#card_c5").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C4 +
                        ".png");
                }
                if (data.t1[0].C5 != 1) {
                    $("#card_c3").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C5 +
                        ".png");
                }
                if (data.t1[0].C6 != 1) {
                    $("#card_c6").attr("src", site_url + "storage/front/img/cards_new/" + data.t1[0].C6 +
                        ".png");
                }
            }
            clock.setValue(data1.t1[0].autotime);
            $(".round_no").text(data1.t1[0].mid == 0 ? 0 : data1.t1[0].mid);
            $("#casino_event_id").val(data1.t1[0].mid == 0 ? 0 : data1.t1[0].mid);
            eventId = data1.t1[0].mid == 0 ? 0 : data1.t1[0].mid;
            var suit_markets = "";
            var odd_markets = "";
            var cards_markets = "";
            for (var j in data.t2) {
                selectionid = data.t2[j].sectionId || data.t2[j].sid;
                runner = data.t2[j].nation || data.t2[j].nat;
                b1 = data.t2[j].b1;
                bs1 = data.t2[j].bs1;
                l1 = data.t2[j].l1;
                ls1 = data.t2[j].ls1;
                visible = data.t2[j].visible;
                back_html = '<span class="odds d-block"><b>' + b1 + '</b></span> ';
                $(".market_" + selectionid + "_b_btn").attr("side", "Back");
                $(".market_" + selectionid + "_b_btn").attr("selectionid", selectionid);
                $(".market_" + selectionid + "_b_btn").attr("marketid", selectionid);
                $(".market_" + selectionid + "_b_btn").attr("runner", runner);
                $(".market_" + selectionid + "_b_btn").attr("marketname", runner);
                $(".market_" + selectionid + "_b_btn").attr("eventid", eventId);
                $(".market_" + selectionid + "_b_btn").attr("markettype", markettype);
                $(".market_" + selectionid + "_b_btn").attr("event_name", markettype);
                $(".market_" + selectionid + "_b_btn").attr("fullmarketodds", b1);
                $(".market_" + selectionid + "_b_btn").attr("fullfancymarketrate", b1);
                $(".market_" + selectionid + "_b_btn").html(back_html);

                lay_html = '<span class="odds d-block"><b>' + l1 + '</b></span>';
                $(".market_" + selectionid + "_l_btn").attr("side", "Back");
                $(".market_" + selectionid + "_l_btn").attr("selectionid", selectionid);
                $(".market_" + selectionid + "_l_btn").attr("marketid", selectionid);
                $(".market_" + selectionid + "_l_btn").attr("runner", runner);
                $(".market_" + selectionid + "_l_btn").attr("marketname", runner);
                $(".market_" + selectionid + "_l_btn").attr("eventid", eventId);
                $(".market_" + selectionid + "_l_btn").attr("markettype", markettype);
                $(".market_" + selectionid + "_l_btn").attr("event_name", markettype);
                $(".market_" + selectionid + "_l_btn").attr("fullmarketodds", l1);
                $(".market_" + selectionid + "_l_btn").attr("fullfancymarketrate", l1);
                $(".market_" + selectionid + "_l_btn").html(lay_html);

                var statuss = "";
                gstatus = data.t2[j].gstatus.toString();
                if (gstatus == "SUSPENDED" || gstatus == "0") {
                    $(".market_" + selectionid + "_l_btn").addClass("suspended-box");
                    $(".market_" + selectionid + "_b_btn").addClass("suspended-box");
                    statuss = "suspended-box";
                } else {
                    $(".market_" + selectionid + "_l_btn").removeClass("suspended-box");
                    $(".market_" + selectionid + "_b_btn").removeClass("suspended-box");
                }

                subtype = data.t2[j].subtype;
                if (data.t2[j].odds && visible == "1") {
                    for (var k in data.t2[j].odds) {
                        odd_selectionid = data.t2[j].odds[k].sectionId || data.t2[j].odds[k].sid;
                        odd_runner = data.t2[j].odds[k].nation || data.t2[j].odds[k].nat;
                        odd_b1 = data.t2[j].odds[k].b;
                        new_selectionid = selectionid + "_" + odd_selectionid;
                        new_runner = runner + " - " + odd_runner;

                        if (subtype == "suit") {

                            suit_markets += ` 
                          
                                                    <div class="casino-odds-box back back-1 market_${new_selectionid}_row ${statuss} market_${new_selectionid}_b_btn" side="Back" selectionid="${new_selectionid}" marketid="${new_selectionid}" runner="${new_runner}" marketname="${new_runner}" eventid="${eventId}" markettype="${markettype}" event_name="${markettype}" fullmarketodds="${odd_b1}" fullfancymarketrate="${odd_b1}">
                                                        <div class="bltitle"><img src="../storage/front/img/cards/${odd_runner.toLowerCase()}_race.png"></div>
                                                        <div><span class="casino-odds">${odd_b1}</span></div>
                                                    </div>
                                                    `;
                        }
                        if (subtype == "oddeven") {


                            odd_markets += `
                                                    <div class="casino-odds-box back back-1 market_${new_selectionid}_row ${statuss} market_${new_selectionid}_b_btn" side="Back" selectionid="${new_selectionid}" marketid="${new_selectionid}" runner="${new_runner}" marketname="${new_runner}" eventid="${eventId}" markettype="${markettype}" event_name="${markettype}" fullmarketodds="${odd_b1}" fullfancymarketrate="${odd_b1}">
                                                        <div><b>${odd_runner}</b></div>
                                                        <div><span class="casino-odd">${odd_b1}</span></div>
                                                    </div>
                                                    `;
                        }
                        if (subtype == "cards") {


                            cards_markets += ` <div class="card-odd-box"><span class="casino-odds">${odd_b1}</span>
                                                        <div class=" back-1 market_${new_selectionid}_row ${statuss}  market_${new_selectionid}_b_btn" side="Back" selectionid="${new_selectionid}" marketid="${new_selectionid}" runner="${new_runner}" marketname="${new_runner}" eventid="${eventId}" markettype="${markettype}" event_name="${markettype}" fullmarketodds="${odd_b1}" fullfancymarketrate="${odd_b1}"><img src="../storage/front/img/andar_bahar/${odd_selectionid}.jpg"></div>
                                                    </div>
                                                    `;
                        }


                    }
                }
            }
            $(".other_markets").html(
                `<div class="teen2other">${suit_markets}${odd_markets}</div>  <div class="w-100 casino-table-full-box teen2cards mt-3">${cards_markets}</div>`
                );
        }
    });
    socket.on('gameResult', function(args) {
        if (args.data) {
            updateResult(args.data);
        } else {
            updateResult(args['res']);
        }
    });
    socket.on('error', function(data) {});
    socket.on('close', function(data) {});
}

function clearCards() {
    refresh(markettype);
    $("#card_c1").attr("src", site_url + "storage/front/img/cards/1.png");
    $("#card_c2").attr("src", site_url + "storage/front/img/cards/1.png");
    $("#card_c3").attr("src", site_url + "storage/front/img/cards/1.png");
    $("#card_c4").attr("src", site_url + "storage/front/img/cards/1.png");
    $("#card_c5").attr("src", site_url + "storage/front/img/cards/1.png");
    $("#card_c6").attr("src", site_url + "storage/front/img/cards/1.png");
}

function updateResult(data) {
    if (data && data[0]) {
        data = JSON.parse(JSON.stringify(data));
        resultGameLast = data[0].mid;

        if (last_result_id != resultGameLast) {
            last_result_id = resultGameLast;
        }

        var html = "";
        casino_type = "'teen6'";
        data.forEach((runData) => {

            eventId = runData.mid == 0 ? 0 : runData.mid;
            html += '<span onclick="view_casiono_result(' + eventId + ',' + casino_type +
                ')"  class="last-result ml-1 ' + (parseInt(runData.win) == 1 ? 'playera' : 'playerb') + '">' + (
                    parseInt(runData.win) == 1 ? 'A' : 'B') + '</span>';
        });
        $("#last-result").html(html);
        if (oldGameId == 0 || oldGameId == resultGameLast) {
            $("#card_c1").attr("src", site_url + "storage/front/img/cards/1.png");
            $("#card_c2").attr("src", site_url + "storage/front/img/cards/1.png");
            $("#card_c3").attr("src", site_url + "storage/front/img/cards/1.png");
            $("#card_c4").attr("src", site_url + "storage/front/img/cards/1.png");
            $("#card_c5").attr("src", site_url + "storage/front/img/cards/1.png");
            $("#card_c6").attr("src", site_url + "storage/front/img/cards/1.png");
        }
    }
}

function teenpatti(type) {
    gameType = type
    websocket();
}
teenpatti("ok");
jQuery(document).on("click", ".back-1", function() {
    $("#popup_color").removeClass("back");
    $("#popup_color").removeClass("lay");
    $("#popup_color").addClass("back");
    var fullmarketodds = $(this).attr("fullmarketodds");
    if (fullmarketodds != "") {
        side = $(this).attr("side");
        selectionid = $(this).attr("selectionid");
        market_odd_name = $(this).attr("markettype");
        runner = $(this).attr("runner");
        market_runner_name = runner;
        marketname = $(this).attr("marketname");
        markettype = $(this).attr("markettype");
        fullfancymarketrate = $(this).attr("fullfancymarketrate");
        odds_change_value = "disabled";
        runs_lable = 'Runs';
        runs_lable = 'Odds';
        fullfancymarketrate = fullmarketodds;
        eventId = $(this).attr("eventid");
        marketId = $(this).attr("marketid");
        event_name = $(this).attr("event_name");
        $(".select").removeClass("select");
        $(this).addClass("select");
        return_html = "";

        $("#inputStake").val();
        $("#market_runner_label").text(market_runner_name);
        $("#bet_stake_side").val("Back");
        $("#odds_val").val(fullmarketodds);
        $("#bet_event_id").val(eventId);
        $("#bet_marketId").val(marketId);
        $("#bet_event_name").val(event_name);
        $("#bet_market_name").val(marketname);
        $("#bet_markettype").val(markettype);
        $("#fullfancymarketrate").val(fullfancymarketrate);
        $("#oddsmarketId").val(marketId);
        $("#market_runner_name").val(market_runner_name);
        $("#market_odd_name").val(market_odd_name);

        $('#profitLiability').text('0');
        $(".placeBet").attr('disabled', false);
        $("#inputStake").val("0");

        $('.open_back_place_bet').show();
        $('#open_back_place_bet').modal("show");
    }
});
jQuery(document).on("click", ".lay-1", function() {
    $("#popup_color").removeClass("back");
    $("#popup_color").removeClass("lay");
    $("#popup_color").addClass("lay");
    var fullmarketodds = $(this).attr("fullmarketodds");
    if (fullmarketodds != "") {
        side = $(this).attr("side");
        selectionid = $(this).attr("selectionid");
        market_odd_name = $(this).attr("markettype");
        runner = $(this).attr("runner");
        market_runner_name = runner;
        marketname = $(this).attr("marketname");
        markettype = $(this).attr("markettype");
        fullfancymarketrate = $(this).attr("fullfancymarketrate");
        odds_change_value = "disabled";
        runs_lable = 'Runs';
        runs_lable = 'Odds';
        fullfancymarketrate = fullmarketodds;
        eventId = $(this).attr("eventid");
        marketId = $(this).attr("marketid");
        event_name = $(this).attr("event_name");
        $(".select").removeClass("select");
        $(this).addClass("select");
        return_html = "";

        $("#inputStake").val();
        $("#market_runner_label").text(market_runner_name);
        $("#bet_stake_side").val("Lay");
        $("#odds_val").val(fullmarketodds);
        $("#bet_event_id").val(eventId);
        $("#bet_marketId").val(marketId);
        $("#bet_event_name").val(event_name);
        $("#bet_market_name").val(marketname);
        $("#bet_markettype").val(markettype);
        $("#fullfancymarketrate").val(fullfancymarketrate);
        $("#oddsmarketId").val(marketId);
        $("#market_runner_name").val(market_runner_name);
        $("#market_odd_name").val(market_odd_name);

        $('#profitLiability').text('0');
        $(".placeBet").attr('disabled', false);
        $("#inputStake").val("0");

        $('.open_back_place_bet').show();
        $('#open_back_place_bet').modal("show");
    }
});

jQuery(document).on("input", "#inputStake", function() {
    var stake = $("#inputStake").val();
    eventId = $("#fullMarketBetsWrap").attr("eventid");
    $("#inputStake").val(stake);
    odds = parseFloat($("#odds_val").val());
    inputStake = $("#inputStake").val();
    bet_stake_side = $("#bet_stake_side").val();
    bet_markettype = $("#bet_markettype").val();
    if (bet_markettype != "FANCY_ODDS") {
        if (bet_stake_side == "Lay") {
            profit = parseInt(inputStake);
        } else {
            profit = (odds - 1) * inputStake;
        }
    }
    $("#profitLiability").text(profit.toFixed(2));
});
jQuery(document).on("click", ".label_stake", function() {
    stake = $(this).attr("stake");
    eventId = $("#fullMarketBetsWrap").attr("eventid");
    $("#inputStake").val(stake);
    odds = parseFloat($("#odds_val").val());
    inputStake = $("#inputStake").val();
    bet_stake_side = $("#bet_stake_side").val();
    bet_markettype = $("#bet_markettype").val();
    if (bet_markettype != "FANCY_ODDS") {
        if (bet_stake_side == "Lay") {
            profit = (odds - 1) * inputStake;
        } else {
            profit = (odds - 1) * inputStake;
        }
    }
    $("#profitLiability").text(profit.toFixed(2));
});

jQuery(document).on("click", "#placeBet", function() {

    $("#placeBet").html('<i class="fa fa-spinner  fa-spin"></i> Submit');
    $(".placeBet").attr('disabled', true);
    $(".placeBet").removeAttr("id", "placeBet");
    var last_place_bet = "";
    bet_stake_side = $("#bet_stake_side").val();
    bet_type = bet_stake_side;
    bet_event_id = $("#bet_event_id").val();
    bet_marketId = $("#bet_marketId").val();
    oddsmarketId = bet_marketId;
    eventType = 'TEEN6';
    bet_event_name = $("#bet_event_name").val();
    inputStake = $("#inputStake").val();
    market_runner_name = $("#market_runner_name").val();
    market_odd_name = $("#market_odd_name").val();
    var runsNo;
    var oddsNo;
    bet_market_name = $("#bet_market_name").val();
    eventManualType = 'Auto';
    if (bet_stake_side == "Lay") {
        type = "No";
        class_type = "no";
        unmatched_side_type = false;
    } else {
        type = "Yes";
        class_type = "yes";
        unmatched_side_type = true;
    }
    bet_markettype = $("#bet_markettype").val();
    if (bet_markettype != "FANCY_ODDS") {
        bet_market_type = bet_markettype;
        runsNo = parseFloat($("#odds_val").val());
        oddsNo = parseFloat($("#odds_val").val());
        if (bet_stake_side == "Lay") {
            return_stake = (oddsNo - 1) * inputStake;
            return_stake = parseInt(return_stake);
        } else {
            return_stake = (oddsNo - 1) * inputStake;
            return_stake = parseInt(return_stake);
        }
        bet_seconds = 1;
        bet_sec = 1000;
    }

    /* $("#inputStake").val(""); */
    $(".back-1").removeClass("select");
    $(".lay-1").removeClass("select");
    $("#loadingMsg").show();
    $('.header_Back_' + bet_event_id).remove();
    $('.header_Lay_' + bet_event_id).remove();
    $('#betSlipFullBtn').hide();
    $('#backSlipHeader').hide();
    $('#laySlipHeader').hide();
    $(".back-1").removeClass("select");
    $(".lay-1").removeClass("select");

    $("#bet-error-class").removeClass("b-toast-danger");
    $("#bet-error-class").removeClass("b-toast-success");
    setTimeout(function() {
        $.ajax({
            type: 'POST',
            url: '../ajaxfiles/bet_place_teen6.php',
            dataType: 'json',
            data: {
                eventId: bet_event_id,
                eventType: eventType,
                marketId: bet_marketId,
                stack: inputStake,
                type: type,
                odds: oddsNo,
                runs: runsNo,
                bet_market_type: bet_market_type,
                oddsmarketId: oddsmarketId,
                eventManualType: eventManualType,
                market_runner_name: market_runner_name,
                market_odd_name: market_odd_name,
                bet_event_name: bet_event_name,
                bet_type: bet_type
            },
            success: function(response) {
                var check_status = response['status'];
                var message = response['message'];
                if (check_status == 'ok') {
                    if (bet_markettype != "FANCY_ODDS") {
                        oddsNo = runsNo;
                    } else {
                        oddsNo = oddsNo;
                    }
                    auth_key = 1;
                    $("#bet-error-class").addClass("b-toast-success");
                } else {
                    $("#bet-error-class").addClass("b-toast-danger");
                }
                error_message_text = message;
                $("#errorMsgText").text(error_message_text);
                $("#errorMsg").fadeIn('fast').delay(3000).hide(0);
                $(".close-bet-slip").click();
                refresh(markettype);
                $(".placeBet").attr("id", "placeBet");
                $("#placeBet").html('Submit');
                $(".placeBet").attr('disabled', false);
                $('.open_back_place_bet').hide();
                $('#open_back_place_bet').modal("hide");
            }
        });
    }, bet_sec - 2000);
});
</script>
<div id="open_back_place_bet" class="modal open_back_place_bet" role="dialog">
    <div class="modal-dialog">
        <div role="document" id="__BVID__30___BV_modal_content_" tabindex="-1" class="modal-content">
            <header id="__BVID__30___BV_modal_header_" class="modal-header">
                <h5 id="__BVID__30___BV_modal_title_" class="modal-title">Placebet</h5>
                <button type="button" data-dismiss="modal" class="close">&times;</button>
            </header>
            <div id="__BVID__30___BV_modal_body_" class="modal-body" style="    padding: 0px;">
                <div class="place-bet pt-2 pb-2 back" id="popup_color">
                    <div class="container-fluid container-fluid-5">
                        <div class="row row5">
                            <div class="col-5"><b id="market_runner_label">Player A</b></div>
                            <div class="col-7 text-right">
                                <div class="float-right">
                                    <button class="stakeactionminus btn disabled">
                                        <span class="fa fa-minus"></span>
                                    </button>
                                    <input type="text" placeholder="0" class="stakeinput" id="odds_val">
                                    <button class="stakeactionminus btn disabled">
                                        <span class="fa fa-plus"></span>
                                    </button>
                                    <input type='hidden' id='bet_stake_side' value='' /><input type='hidden'
                                        id='bet_event_id' value='' /><input type='hidden' id='bet_marketId'
                                        value='' /><input type='hidden' id='bet_event_name' value='' /><input
                                        type='hidden' id='bet_market_name' value='' /><input type='hidden'
                                        id='bet_markettype' value='' /><input type='hidden' id='fullfancymarketrate'
                                        value='' /> <input type='hidden' id='oddsmarketId' value='' /><input
                                        type='hidden' id='market_runner_name' value='' /><input type='hidden'
                                        id='market_odd_name' value='' />
                                </div>
                            </div>
                        </div>
                        <div class="row row5 mt-2">
                            <div class="col-4">
                                <input type="number" placeholder="00" id="inputStake" class="stakeinput w-100">
                            </div>
                            <div class="col-4">
                                <button class="btn btn-primary btn-block  placeBet" id="placeBet">
                                    <!---->Submit
                                </button>
                            </div>
                            <div class="col-4 text-center pt-1"><span id="profitLiability">0</span></div>
                        </div>
                        <div class="row row5 mt-2">
                            <?php
                            $get_button_value = $conn->query("select * from user_master where id=$user_id and (button_value <> '' and button_value IS NOT NULL)");
                            $num_rows = $get_button_value->num_rows;
                            $button_array = array();
                            if ($num_rows <= 0) {
                                $button_array[] = 500;
                                $button_array[] = 1000;
                                $button_array[] = 2000;
                                $button_array[] = 3000;
                                $button_array[] = 4000;
                                $button_array[] = 5000;
                                $button_array[] = 10000;
                                $button_array[] = 20000;
                            } else {
                                $fetch_button_value_data = mysqli_fetch_assoc($get_button_value);
                                $fetch_button_value = $fetch_button_value_data['button_value'];
                                $default_stake = $fetch_button_value_data['default_stake'];
                                $one_bet_default_stake = $fetch_button_value_data['one_bet_default_stake'];
                                $button_array = explode(",", $fetch_button_value);
                            }
                            foreach ($button_array as $button_value) {
                            ?>
                            <div class="col-4">
                                <button type="button" class="btn btn-secondary btn-block mb-2 label_stake"
                                    stake='<?php echo $button_value; ?>'>
                                    <?php echo $button_value; ?>
                                </button>
                            </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!---->
        </div>
    </div>
</div>
<div id="errorMsg" class="b-toaster b-toaster-top-center" style="display:none;">
    <div class="b-toaster-slot vue-portal-target">
        <div role="alert" aria-live="assertive" aria-atomic="true" id="bet-error-class"
            class="b-toast b-toast-solid b-toast-prepend b-toast-danger">
            <div tabindex="0" class="toast">
                <header class="toast-header"><strong class="mr-2" id="errorMsgText"></strong>
                    <button type="button" aria-label="Close" class="close ml-auto mb-1">&times;</button>
                </header>
                <div class="toast-body"> </div>
            </div>
        </div>
    </div>
</div>
<?php
include "footer.php";
include "footer-result-popup.php";
?>

</html>