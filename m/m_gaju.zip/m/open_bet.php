<div id="match" class="tab-pane">
                            <div class="table-responsive m-u-table">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="box-6">Nation</th>
                                            <th class="box-2 text-right">Odds</th>
                                            <th class="box-2 text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr id="matched_bet">
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>