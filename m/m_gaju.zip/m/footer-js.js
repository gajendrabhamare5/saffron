/* if(typeof markettype === 'undefined') {
		markettype = 1;
}
refresh(markettype);
 */
if (typeof markettype === 'undefined') {
    markettype = 1;
}
$.ajax({
    type: 'POST',
    url: '../ajaxfiles/refresh_balance.php',
    dataType: 'json',
    data: { curPageName: curPageName },
    success: function(response) {
        var account_balance = response.balance;
        var account_exposure = response.exposure;
        var account_winning_exposure = response.winning;
        $("#betCredit").text(account_balance);
        $("#betExposure").text("Exp:" + account_exposure);
        $("#betWinningExposure").text(account_winning_exposure);
    }
});
setTimeout(function() {
    if (typeof markettype === 'undefined') {
        markettype = 1;
    }

    if (typeof eventIdOpenbet === 'undefined') {
        eventIdOpenbet = 1;
    }

    console.log(markettype + "toim log");
    refresh(markettype, eventIdOpenbet);
}, 2000);

function refresh(markettype = 1, eventId = 1) {
    var open_bet = [];
    var html_open_bet_details = "";
    $.ajax({
        type: 'POST',
        url: '../ajaxfiles/open_bet.php',
        dataType: 'json',
        data: { markettype: markettype, eventId: eventId, curPageName: curPageName },
        success: function(response) {
            var check_status = response['status'];
            if (check_status == "ok") {
                open_bet_data = response['open_bet_data'];
                if (open_bet_data) {
                    i = 0;
                    for (i = 0; i < open_bet_data.length; i++) {
                        bet_stack = open_bet_data[i].bet_stack;
                        market_name = open_bet_data[i].market_name;
                        bet_odds = open_bet_data[i].bet_odds;
                        bet_runs = open_bet_data[i].bet_runs;
                        bet_runs2 = open_bet_data[i].bet_runs2;
                        event_name = open_bet_data[i].event_name;
                        bet_type = open_bet_data[i].bet_type;
                        market_type = open_bet_data[i].market_type;
                        if (bet_type == "No" || bet_type == "Lay") {
                            class_type = "lay";
                        } else {
                            class_type = "back";
                        }

                        var odds = bet_odds;

                        if (market_type == "BOOKMAKER_ODDS" || market_type == "BOOKMAKERSMALL_ODDS") {
                            odds = parseFloat(odds) * 100 - 100;
                            var odds_length = odds.toString().length;
                            if (odds_length > 4) {
                                odds = odds.toFixed(2);
                            }
                        }

                        if (market_type == "KHADO_ODDS") {
                            odds = bet_runs;
                            market_name += '-' + ((bet_runs2 - bet_runs) + 1);
                        } else if (bet_runs > 0) {
                            odds = bet_runs;
                            market_name += ' / ' + bet_odds;
                        }

                        html_open_bet_details += "<tr class='" + class_type + " open_bet'><td>" + market_name + "</td> <td class='text-right'><span>" + odds + "</span></td> <td style='text-align: right;'>" + bet_stack + "</td></tr>";
                    }
                    $("#count_open_bet").text(i);
                    $(".open_bet").remove();

                    $("#matched_bet").after(html_open_bet_details);
                } else {
                    $(".open_bet").remove();
                    $("#count_open_bet").text(0);
                }
            }
        }
    });

    $.ajax({
        type: 'POST',
        url: '../ajaxfiles/refresh_balance.php',
        dataType: 'json',
        data: { curPageName: curPageName },
        success: function(response) {
            var account_balance = response.balance;
            var account_exposure = response.exposure;
            var account_winning_exposure = response.winning;
            $("#betCredit").text(account_balance);
            $("#betExposure").text("Exp:" + account_exposure);
            $("#betWinningExposure").text(account_winning_exposure);
        }
    });


    main_event_id = $(".round_no").text();

    $.ajax({
        type: 'POST',
        url: '../ajaxfiles/get_casino_on_page_exposure.php',
        dataType: 'json',
        data: { markettype: markettype, main_event_id: main_event_id, curPageName: curPageName },
        success: function(response) {
            status = response.status;
            if (status == "ok") {
                total_exposure_data = response.data;


                $(".market_exposure").css("color", "black");
                $(".market_exposure").text("0");

                for (var exp in total_exposure_data) {
                    market_id = total_exposure_data[exp].market_id;
                    total_exposure = total_exposure_data[exp].total_exposure;

                    if (total_exposure < 0) {
                        $(".market_" + market_id + "_b_exposure").css("color", "red");
                        $(".market_" + market_id + "_b_exposure").text(total_exposure);
                    } else {
                        $(".market_" + market_id + "_b_exposure").css("color", "green");
                        $(".market_" + market_id + "_b_exposure").text(total_exposure);
                    }

                }


            }
        }
    });
}
jQuery(document).on("click", "#headerMenu", function() {
    if ($(".headerMenu1").is(":visible")) {
        $(".headerMenu1").hide();
    } else {
        $(".headerMenu1").show();
    }
});
jQuery(document).on("click", '.nav-link', function() {
    $('.nav-link').removeClass('active');
    $(this).addClass('active');
});
jQuery(document).on("click", "#headerMenu2", function(event) {
    event.stopPropagation();
    if ($(".headerMenu12").is(":visible")) {
        $(".headerMenu12").hide();
    } else {
        $(".headerMenu12").show();
    }
});
jQuery(document).on("click", function(event) {
    // Check if the clicked element is outside of the menu or the toggle button
    if (!$(event.target).closest("#headerMenu2").length && !$(event.target).closest(".headerMenu12").length) {
        $(".headerMenu12").hide();
    }
});
jQuery(document).on("click", "#searchHeader", function() {
    if ($("#searchHeader1").hasClass("search_input-hover")) {
        $("#searchHeader1").removeClass("search_input-hover");
        $("#searchB").removeClass('fa-times');
        $("#searchB").addClass('fa-search');
    } else {
        $("#searchHeader1").addClass("search_input-hover");
        $("#searchB").removeClass('fa-search');
        $("#searchB").addClass('fa-times');
    }
});

function balance_exposure() {
    var balance_value = "on";
    balance_value = $('input[name="balance_exposure"]:checked').val();

    if (balance_value == "on") {
        $("#betExposure").show();
    } else {
        $("#betExposure").hide();
    }
}

function balance_checkbox() {
    var balance_value = "on";
    balance_value = $('input[name="balance_checkbox"]:checked').val();

    if (balance_value == "on") {
        $("#betCredit").show();
    } else {
        $("#betCredit").hide();
    }
}

//setInterval(check_authantication,1000 * 30)

function check_authantication() {
    $.ajax({
        type: 'POST',
        url: '../ajaxfiles/auth.php',
        dataType: 'json',
        success: function(response) {
            if (response.status == false) {
                window.location.href = 'login';
            }
        }
    });
}


jQuery(document).on("click", ".close", function() {
    $("#errorMsg").hide();
});

$(document).ready(function() {

    $('#btn_exposure_popup').on('click', function() {
        $(".loader").show();
        $.ajax({
            type: 'POST',
            url: '../ajaxfiles/myExposure',
            dataType: 'json',
            success: function(response) {
                if (response) {

                    var popup_body = '';
                    for (var i = 0; i < response.length; i++) {

                        var eventType = response[i].eventType;
                        var sport_category = 'Other';
                        if (eventType == 1) {
                            sport_category = 'Soccer';
                        } else if (eventType == 2) {
                            sport_category = 'Tennis';
                        } else if (eventType == 4) {
                            sport_category = 'Cricket';
                        } else if (eventType == 8) {
                            sport_category = 'Election';
                        }

                        popup_body += '<tr>';
                        popup_body += '	<td>' + sport_category + '</td>';
                        popup_body += '	<td><a href="/m/event_full_market?eventType=' + response[i].eventType + '&eventId=' + response[i].eventId + '&marketId=' + response[i].oddsmarketId + '" class="text-link">' + response[i].eventName + '</a></td>';
                        popup_body += '	<td>MATCH_ODDS</td>';
                        popup_body += '	<td>' + response[i].trade + '</td>';
                        popup_body += '</tr>';
                    }

                    if (response.length == 0) {
                        popup_body += '<tr>';
                        popup_body += '	<td colspan="100%" align="center">No real-time records found</td>';
                        popup_body += '</tr>';
                    }

                    $('#myMarketTableBody').html(popup_body);
                    $('#myMarketModal').modal('show');
                    $(".loader").hide();
                }
                return false;
            }
        });
        return false;
    });

});

if (markettype_2 === undefined)
    var markettype_2 = markettype;

function view_rules(gametype = "") {
    var image_url = "";
    var return_data = "";
    var ruletitle = "Rules";

    if(gametype == ""){
        gametype = markettype_2;
    }

    if (gametype == "BACCARAT") {
        image_url = "baccarat.jpg";
    } else if (gametype == "2020_DRAGON_TIGER2") {
        image_url = "dragon-tiger-20-rules.jpg";
    } else if (gametype == "BACCARAT2") {
        image_url = "baccarat2-rules.jpg";
    } else if (gametype == "LUCKY7B") {
        image_url = "lucky7-rules.jpg";
    } else if (gametype == "2020_CRICKET_MATCH") {
        image_url = "cmatch20-rules.jpg";
    } else if (gametype == "CASINO_METER") {
        image_url = "cmeter-rules.jpg";
    } else if (gametype == "CASINO_WAR") {
        image_url = "war-rules.jpg";
    } else if (gametype == "DTL20") {
        image_url = "dtl20-rules.jpg";
    } else if (gametype == "TESTTEENPATTI") {
        image_url = "tp-rules.jpg";
    } else if (gametype == "ODITEENPATTI") {
        image_url = "tp-rules.jpg";
    } else if (gametype == "OPENTEENPATTI") {
        // image_url = "tp-rules.jpg";
        image_url = "<div class='rules-section'><ul class='pl-2 pr-2 list-style'><li>The game is played with a regular 52 cards single deck, between 2 players A and B.</li><li>Each player will receive 3 cards.</li><li><b>Rules of regular teenpatti winner</b></li></ul> <div><img src='https://sitethemedata.com/casino-new-rules-images/teen20b.jpg'></div></div>";
    } else if (gametype == "2020TEENPATTI") {
        // image_url = "tp-rules.jpg";
        
    } else if (gametype == "ODI_POKER") {
        image_url = "poker-rules.jpeg";
    } else if (gametype == "6_PLAYER_POKER") {
        image_url = "poker-rules.jpeg";
    } else if (gametype == "2020_POKER") {
        image_url = "poker-rules.jpeg";
    } else if (gametype == "32CARDS") {
        image_url = "tt_cards_rule.jpg";
    } else if (gametype == "ODI_DRAGON_TIGER") {
        image_url = "dt6-rules.jpg";
    } else if (gametype == "2020_DRAGON_TIGER") {
        image_url = "dragon-tiger-20-rules.jpg";
    } else if (gametype == "32CARDSB") {
        image_url = "tt_cards_rule.jpg";
    } else if (gametype == "AMAR_AKBAR_ANTHONY") {
        image_url = "aaa-rules.jpg";
    } else if (gametype == "B_TABLE") {
        image_url = "ddb-rules.jpg";
    } else if (gametype == "LUCKY7") {
        image_url = "lucky7-rules.jpg";
    } else if (gametype == "RACE_20") {
        image_url = "race20.jpg";
    } else if (gametype == "ABJ") {
        image_url = "abj-rules.jpg";
    } else if (gametype == "SUPER_OVER") {
        image_url = "superover.jpg";
    } else if (gametype == "cmeter1") {
        ruletitle = "1 Card Meter Rules";
        image_url = `<div class="rules-section">
                                            <ul class="pl-0 pr-4 list-style">
                                                <li>1 Card meter will be played with 8 deck of cards.</li>
                                                <li>In this game the value of the cards will be as follow
                                                    <p>ACE =1, 2=2, 3=3, ……, Jack =11, Queen=12, King=13.</p>
                                                </li>
                                                <li>In this game there will be two players which will be named as Fighter A &amp; Fighter B.</li>
                                                <li>1 card each will be dealt to both the fighters.</li>
                                                <li>In this game the winner will be the fighter who will have the higher value card and also his point difference will be calculated.</li>
                                            </ul>
                                            <p>For example,</p>
                                            <p>Fighter A has 7.</p>
                                            <p>Fighter B has King (K).</p>
                                            <p>So fighter B will be the winner with 6 points (13-7 = 6).</p>
                                            <p>here the winning amount will be calculated on the point differences.</p>
                                            <p>Like,</p>
                                            <p>1 point 1 time bet amount.</p>
                                            <p>2 points 2 times bet amount.</p>
                                            <p>3 points 3 times bet amount.</p>
                                            <p>4 points 4 times bet amount.</p>
                                            <p>5 points 5 times bet amount.</p>
                                            <p>6 points 6 times bet amount.</p>
                                            <p>7 points 7 times bet amount.</p>
                                            <p>8 points 8 times bet amount.</p>
                                            <p>9 points 9 times bet amount.</p>
                                            <p>10 points 10 times bet amount.</p>
                                            <p>11 points 11 times bet amount.</p>
                                            <p>12 points 12 times bet amount.</p>
                                            <p>(12 times bet amount will be the highest)</p>
                                            <p>So in this case the difference is 6 points thus the winning amount for Fighter B will be 6 times of the bet amount and similarly For Fighter A the losing amount will be 6 times of the bet amount.</p>
                                            <ul class="pl-4 pr-4 list-style">
                                                <li>In this game If punter place bet of 100 amount &amp; If he loses by 12 points then he will lose 1200 amount.
                                                    <p>In short in this game punter can win or lose up to 12 times of his betting amount. </p>
                                                </li>
                                                <li>If both the fighters have same value cards but of different suits then the winner will be decided by the ranking of the suits
                                                    <p>Ie. Spades hearts clubs diamonds</p>
                                                    <p>And in this case the winning amount will be 1 time of the bet amount.
                                                    </p>
                                                    <p>If both the fighters have the same value cards and of the same suits then in this case it will be a tieand the bet amount will be pushed( Returned)</p>
                                                </li>
                                                <li>2% will be charged on winning amount only.</li>
                                            </ul>
                                        </div>`;
    } else if(gametype == "dum10") {
        ruletitle = "Dus Ka Dum Rules";
        image_url = `<div class="rules-section">
                                            <ul class="pl-4 pr-4 list-style">
                                                <li>Dus Ka Dum is an unique and instant result game.</li>
                                                <li>It is played with a regular single deck of 52 cards.</li>
                                                <li>In this game each card has point value</li>
                                            </ul>
                                            <h6 class="rules-highlight">Point value of cards:</h6>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <tbody>
                                                        <tr>
                                                            <td>Ace = 1</td>
                                                            <td>8 = 8</td>
                                                        </tr>
                                                        <tr>
                                                            <td>2 = 2</td>
                                                            <td>9 = 9</td>
                                                        </tr>
                                                        <tr>
                                                            <td>3 = 3</td>
                                                            <td>10 = 10</td>
                                                        </tr>
                                                        <tr>
                                                            <td>4 = 4</td>
                                                            <td>J = 11</td>
                                                        </tr>
                                                        <tr>
                                                            <td>5 = 5</td>
                                                            <td>Q = 12</td>
                                                        </tr>
                                                        <tr>
                                                            <td>6 = 6</td>
                                                            <td>K = 13</td>
                                                        </tr>
                                                        <tr>
                                                            <td>7 = 7</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <p>(Suit of card is irrelevant in point value)</p>
                                            <ul class="pl-4 pr-4 list-style">
                                                <li>Dus ka Dum is a one card game. The dealer will draw a single card every time which will decide the result of the game. Hence that particular game will be over.</li>
<li>Now always the last drawn card will be removed and kept aside. Thereafter a new game will commence from the remaining cards. Then the same process will continue till there is a winning chance or otherwise up to 35 cards or so.</li>
                                                <li>All the drawn cards will be added to current total.</li>
                                            </ul>
                                            <p>Example1: </p>
                                            <p>If first four drawn cards are: 7, 9, J, 4</p>
                                            <p>So current total is 31, now on opening of 5th card bet will be for next total 40 or more.</p>
                                            <p>Eaxmple2: If the current total of first 11 drawn cards is 84 the bet will open for next total 90 or more.</p>
                                            <p>Example3: The current total of first 12 drawn cards is 79 the bet will open for next total 90 or more (because on opening of any cards 80 is certainty). </p>
                                            <ul class="pl-4 pr-4 list-style">
                                                <li>The objective of the game is to achieve next (decade) total or more and therefor win.</li>
                                                <li>Both back and lay options will be available.</li>
                                            </ul>
                                        </div>`;
    }

    if (image_url != "") {
        // return_data = '<img src="../storage/front/img/rules/' + image_url + '" class="img-fluid">';
        console.log(image_url,"jjjjjjj");
         return_data =  image_url 
    }else{
        console.log("KKKKK")
;    }
    $(".rules_popup_image").html(return_data);
    $(".rules-modal-title").html(ruletitle);
}


if (markettype_2 == "WORLI_MATKA" || markettype_2 == "INSTANT_WORLI" || markettype_2 == "3_CARD_J" || markettype_2 == "AB20") {
    $("#rules_popup_btn").hide();
}

window.onresize = function() {
    if ((window.outerHeight - window.innerHeight) > 100) {
        $(".stop-site").show();
    } else {
        $(".stop-site").hide();
    }
}

if ((window.outerHeight - window.innerHeight) > 100) {
    $(".stop-site").show();
} else {
    $(".stop-site").hide();
}

$(document).ready(function() {
    loader_hide();
});

function loader_hide() {
   $(".loader").hide();
}