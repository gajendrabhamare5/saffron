<?php
	include("../include/conn.php");
	include('../include/flip_function.php');
	include('../session.php');
	$user_id = $_SESSION['CLIENT_LOGIN_ID'];
		
	$get_parent_ids = $conn->query("select parentSuperMDL from user_login_master where UserID=$user_id");
	$fetch_parent_ids = mysqli_fetch_assoc($get_parent_ids);
	$parentSuperMDL = $fetch_parent_ids['parentSuperMDL'];

	$get_access = $conn->query("select cricket_access,soccer_access,soccer_access,video_access from user_master where Id=$parentSuperMDL");
	$fetch_access = mysqli_fetch_assoc($get_access);
	
	if($fetch_access['video_access'] != 1){
		echo "<script>alert('you are does not access this game');window.location.href='/';</script>";
		exit();
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<?php
	include("head_css.php");
?>

<style>

.casino-title{
    display: flex;
}

.casino-title .d-block{
    margin-top:1px;
}

.casino-title a{
    color: #fff;
    text-decoration: underline;
}

.casino-table {
        background-color: #f7f7f7;
        color: #333;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        margin-top: 5px;
    }

    .casino-table-box {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: flex-start;
    }

    .casino-table-box {
        padding: 5px;
    }


    .casino-table-left-box,
    .casino-table-center-box,
    .casino-table-right-box {
        width: 49%;
        border-left: 1px solid #c7c8ca;
        border-right: 1px solid #c7c8ca;
        border-top: 1px solid #c7c8ca;
        background-color: #f2f2f2;
    }
    
    .casino-table-left-box,
    .casino-table-right-box {
        width: 100%;
        padding: 0 5px;
    }

    .casino-table-header,
    .casino-table-row {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        border-bottom: 1px solid #c7c8ca;
    }

    .casino-nation-detail {
        display: flex;
        align-items: flex-start;
        flex-direction: column;
        flex-wrap: wrap;
        justify-content: center;
        padding-left: 5px;
        min-height: 46px;
    }

    .casino-table-header .casino-nation-detail {
        font-weight: bold;
        min-height: unset;
    }

    .casino-odds-box {
        width: 25%;
    }

    .casino-odds-box {
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 5px 0;
        font-weight: bold;
        border-left: 1px solid #c7c8ca;
        cursor: pointer;
        min-height: 46px;
        width:25%;
    }

    .casino-table-header,
    .casino-table-row {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        border-bottom: 1px solid #c7c8ca;
    }

    .casino-odds {
        font-size: 14px;
        font-weight: bold;
        line-height: 1;
    }

    .casino-nation-book {
        font-size: 12px;
        font-weight: bold;
        min-height: 18px;
        z-index: 1;
    }

    .teenpatti20-other-oods {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        width: 100%;
    }

    .teenpatti20-other-oods .casino-table-left-box, .teenpatti20-other-oods .casino-table-right-box {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        border: 0;
        padding-top: 10px;
    }

    .teenpatti20-other-oods .casino-odds-box {
        width: 49%;
        flex-direction: row;
        justify-content: space-between;
        padding: 5px 10px;
    }

    .teenpatti20-other-oods img {
        height: 35px;
    }

    .suspended-box {
        position: relative;
        pointer-events: none;
        cursor: none;
    }

    .suspended-box::before {
        background-image: url(storage/front/img/lock.svg);
        background-size: 17px 17px;
        filter: invert(1);
        -webkit-filter: invert(1);
        background-repeat: no-repeat;
        content: "";
        position: absolute;
        z-index: 1;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-position: center;
        pointer-events: none;
    }

    .casino-odds {
        font-size: 14px;
        font-weight: bold;
        line-height: 1;
    }

    .casino-table-box-divider {
        background-color: #c7c8ca;
        width: 2px;
    }

    .suspended-box::after {
        content: "";
        background-color: #373636d6;
        position: absolute;
        height: 100%;
        width: 100%;
        left: 0;
        top: 0;
        cursor: not-allowed;
        display: flex;
        justify-content: center;
        align-items: center;
        pointer-events: none;
    }

    .casino-table-full-box {
        width: 100%;
        border-left: 1px solid #c7c8ca;
        border-right: 1px solid #c7c8ca;
        border-top: 1px solid #c7c8ca;
        background-color: #f2f2f2;
    }

    .casino-table-full-box {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        padding: 10px;
        border-bottom: 1px solid #c7c8ca;
    }

    .casino-table-full-box img {
        height: 60px;
        z-index: 10;
    }

    .casino-odd-box-container {
        width: 50%;
        display: flex;
        flex-wrap: wrap;
        margin-left: -5px;
        margin-top: 20px;
    }

    .casino-odds-box {
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 5px 0;
        font-weight: bold;
        border-left: 1px solid #c7c8ca;
        cursor: pointer;
        min-height: 46px;
    }

    .casino-odd-box-container .casino-odds-box {
        width: 50%;
    }

    .casino-last-results {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        margin-top: 10px;
        width: 100%;
    }

    .casino-last-results .result {
        background: #355e3b;
        color: #fff;
        height: 25px;
        width: 25px;
        border-radius: 50%;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: bold;
        margin-left: 5px;
        cursor: pointer;
    }

    .casino-last-results .result.result-b {
        color: #ffff33;
    }

    .casino-last-results .result.result-c {
        color: #33c6ff;
    }

    .casino-last-results .result.result-a {
        color: #ff4500;
    }

    .casino-title{
        display: flex;
    }

    .casino-title .d-block{
        margin-top:1px;
    }

    .casino-title a{
        color: #fff;
        text-decoration: underline;
    }
    .suspended:after {
	width: 100% !important;
}

</style>
<body cz-shortcut-listen="true">
    <div id="app">
        <?php
	include ("loader.php");
?>
        <div>
            <?php
				include("header.php");
			?>
            <div class="main-content">
                <!---->
                <!---->
                <div>
                <div class="casino-title"><span class="casino-name">20-20 Teenpatti</span><span class="d-block"><a href="#" onclick="view_rules()" data-target="#rules_popup" data-toggle="modal" id="rules_popup_btn" class="ml-1" role="button">Rules</a></span></div>

<?php
    include("casino_header.php");
?>
                    <div class="tab-content">
                        <div id="bhav" class="tab-pane active">
                            
                            <!---->
                            <div class="casino-video">
                            <iframe id="casinoIframe" src="" width="100%" height="200" style="border: 0px;"></iframe>
                                <!-- <iframe src="<?php echo IFRAME_URL; echo A2020TEENPATTI_CODE; ?>" width="100%" height="200" style="border: 0px;"></iframe> -->
                                <div class="clock clock2digit flip-clock-wrapper">
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul class="flip play">
                                        <li class="flip-clock-before">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">9</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="flip-clock-active">
                                            <a href="#">
                                                <div class="up">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                                <div class="down">
                                                    <div class="shadow"></div>
                                                    <div class="inn">0</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="video-overlay">
                                    <div>
                                        <div>
                                            <h3 class="text-white">PLAYER A</h3>
                                            <div><img id="card_c1" src="../storage/front/img/cards/1.png">
											<img id="card_c2" src="../storage/front/img/cards/1.png">
											<img id="card_c3" src="../storage/front/img/cards/1.png"></div>
                                        </div>
                                        <div>
                                            <h3 class="text-white">PLAYER B</h3>
                                            <div><img id="card_c4" src="../storage/front/img/cards/1.png"> <img id="card_c5" src="../storage/front/img/cards/1.png"> <img id="card_c6" src="../storage/front/img/cards/1.png"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="casino-detail">
                                <div class="casino-table">
                                    <div class="casino-table-box">
                                        <div class="casino-table-left-box">
                                            <div class="casino-table-header">
                                                <div class="casino-nation-detail">Player A</div>
                                            </div>
                                            <div class="casino-table-body">
                                                <div class="casino-table-row">
                                                <div class="casino-odds-box">Player A</div>
                                                <div class="casino-odds-box">3 Baccarat A</div>
                                                <div class="casino-odds-box">Total A</div>
                                                <div class="casino-odds-box">Pair Plus A</div>
                                                </div>
                                                <div class="casino-table-row">
                                                <div class="casino-odds-box back"><span class="casino-odds">1.98</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">1.98</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">2</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">A</span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="teenpatti20-other-oods d-md-none">
                                            <div class="casino-table-left-box">
                                                <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/spade.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/club.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                                </div>
                                                <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/heart.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/diamond.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="casino-table-right-box">
                                            <div class="casino-table-header">
                                                <div class="casino-nation-detail">Player B</div>
                                            </div>
                                            <div class="casino-table-body">
                                                <div class="casino-table-row">
                                                <div class="casino-odds-box">Player B</div>
                                                <div class="casino-odds-box">3 Baccarat B</div>
                                                <div class="casino-odds-box">Total B</div>
                                                <div class="casino-odds-box">Pair Plus B</div>
                                                </div>
                                                <div class="casino-table-row">
                                                <div class="casino-odds-box back"><span class="casino-odds">1.98</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">1.98</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">2</span></div>
                                                <div class="casino-odds-box back"><span class="casino-odds">B</span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="teenpatti20-other-oods d-md-none">
                                            <div class="casino-table-right-box">
                                                <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/spade.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/club.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                                </div>
                                                <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/heart.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/diamond.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="teenpatti20-other-oods d-none d-md-flex">
                                        <div class="casino-table-left-box">
                                            <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/spade.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/club.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                            </div>
                                            <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/heart.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/diamond.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                            </div>
                                        </div>
                                        <div class="casino-table-right-box">
                                            <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/spade.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/club.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                            </div>
                                            <div class="casino-odds-box back">
                                                <div><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/heart.png"><img src="https://versionobj.ecoassetsservice.com/v28/static/front/img/icons/diamond.png"></div>
                                                <div><span class="casino-odds">1.98</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="last-result-tiele"><span>Last Result</span> <span class="float-right"><a href="casinoresults?game_type=teen8" class="">View All</a></span></div>
                                <!-- <div class="last-result-container text-right mt-1" id="last-result"></div> -->
                                <div class="casino-last-results"><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-b">B</span><span class="result result-a">A</span><span class="result result-a">A</span></div>
                                <div class="last-result-tiele mt-1"><span>Rules</span></div>
                                <div class="table-responsive rules-table">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th colspan="2" class="box-10 text-center">Pair Plus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Pair (Double)</td>
                                                <td class="box-3">1 To 1</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Flush (Color)</td>
                                                <td class="box-3">1 To 4</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Straight (Rown)</td>
                                                <td class="box-3">1 To 6</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Trio (Teen)</td>
                                                <td class="box-3">1 To 30</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-bordered">
                                        <!---->
                                        <tbody>
                                            <tr>
                                                <td class="box-7">Straight Flush (Pakki Rown)</td>
                                                <td class="box-3">1 To 40</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php
							include("open_bet.php");
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script type="text/javascript" src="../js/socket.io.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script src="../storage/front/js/flipclock.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src='footer-js.js'></script>

 <script type="text/javascript">
	var site_url = '<?php echo WEB_URL; ?>';
	var websocketurl = '<?php echo GAME_IP; ?>';
	var clock = new FlipClock($(".clock"), {
		clockFace: "Counter"
	});
	var oldGameId = 0;
	var markettype = "2020TEENPATTI";
	var markettype_2 = markettype;
    var resultGameLast = 0;
    var last_result_id = '0';
    
	function websocket(type) {
		socket = io.connect(websocketurl, {
            transports: ['websocket']
        });
		socket.on('connect', function () {
			console.log(1);
			socket.emit('Room', 'teen20');
		});
        socket.on('gameIframe', function(data){
    	$("#casinoIframe").attr('src',data);
    });
		socket.on('game', function (data) {
console.log("data=",data);
			if (data && data['t1'] && data['t1'][0]) {
				
				if(oldGameId != data.t1[0].mid && data.t1[0].mid != 0 && data.t1[0].mid != "0"){
		  		setTimeout(function(){
						clearCards();
					},<?php echo CASINO_RESULT_TIMEOUT; ?>);
		  	}
              oldGameId = data.t1[0].mid;
        		if(data.t1[0].mid != 0 && data.t1[0].mid != "0" && oldGameId != resultGameLast){
					$(".casino-remark")
						.text(data.t1[0].remark);
					if (data.t1[0].C1 != 1) {
						$("#card_c1")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C1 + ".png");
					}
					if (data.t1[0].C2 != 1) {
						$("#card_c2")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C2 + ".png");
					}
					if (data.t1[0].C3 != 1) {
						$("#card_c3")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C3 + ".png");
					}
					if (data.t1[0].C4 != 1) {
						$("#card_c4")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C4 + ".png");
					}
					if (data.t1[0].C5 != 1) {
						$("#card_c5")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C5 + ".png");
					}
					if (data.t1[0].C6 != 1) {
						$("#card_c6")
							.attr("src", site_url + "storage/front/img/cards/" + data.t1[0].C6 + ".png");
					}
				}
				clock.setValue(data.t1[0].autotime);
				$(".timer_game")
					.text("Left Time:" + data.t1[0].autotime);
				$(".round_no")
					.text(data.t1[0].mid == 0 ? 0 : data.t1[0].mid.split(".")[1]);
				$("#casino_event_id")
					.val(data.t1[0].mid == 0 ? 0 : data.t1[0].mid.split(".")[1]);
				eventId = data.t1[0].mid == 0 ? 0 : data.t1[0].mid.split(".")[1];
				for (var j in data['t2']) {
					selectionid = data['t2'][j].sid;
					runner = data['t2'][j].nat || data['t2'][j].nation;
					b1 = data['t2'][j].rate;
					b1_label = b1;
					
					if (selectionid == 2) {
						b1_label = "Pair Plus A";
					}
					if (selectionid == 4) {
						b1_label = "Pair Plus B";
					}
					
					$(".market_"+selectionid+"_b_value").text(b1_label);
					
					markettype = "2020TEENPATTI";
					//back_html = '<span class="odds d-block"><b>' + b1_label + '</b></span> <span class="market_'+selectionid+'_b_exposure market_exposure" style="color: black;">0</span>';
					$(".market_" + selectionid + "_b_btn")
						.attr("side", "Back");
					$(".market_" + selectionid + "_b_btn")
						.attr("selectionid", selectionid);
					$(".market_" + selectionid + "_b_btn")
						.attr("marketid", selectionid);
					$(".market_" + selectionid + "_b_btn")
						.attr("runner", runner);
					$(".market_" + selectionid + "_b_btn")
						.attr("marketname", runner);
					$(".market_" + selectionid + "_b_btn")
						.attr("eventid", eventId);
					$(".market_" + selectionid + "_b_btn")
						.attr("markettype", markettype);
					$(".market_" + selectionid + "_b_btn")
						.attr("event_name", markettype);
					$(".market_" + selectionid + "_b_btn")
						.attr("fullmarketodds", b1);
					$(".market_" + selectionid + "_b_btn")
						.attr("fullfancymarketrate", b1);
				
					gstatus = data['t2'][j].gstatus.toString();
					if (gstatus == "SUSPENDED" || gstatus == "0") {
						$(".market_" + selectionid + "_row")
							.addClass("suspendedtd");
					}
					else {
						$(".market_" + selectionid + "_row")
							.removeClass("suspendedtd");
					}
				}
			}
			else {
				$(".timer_game")
					.text("Left Time:0");
				$(".round_no")
					.text("0");
			}
		});
		socket.on('gameResult', function (args) {
			updateResult(args.data);
		});
		socket.on('error', function (data) {});
		socket.on('close', function (data) {});
	}
	function clearCards(){
				refresh(markettype);
		$("#card_c1").attr("src",site_url + "storage/front/img/cards/1.png");
		$("#card_c2").attr("src",site_url + "storage/front/img/cards/1.png");
		$("#card_c3").attr("src",site_url + "storage/front/img/cards/1.png");
		$("#card_c4").attr("src",site_url + "storage/front/img/cards/1.png");
		$("#card_c5").attr("src",site_url + "storage/front/img/cards/1.png");
		$("#card_c6").attr("src",site_url + "storage/front/img/cards/1.png");
	}

	function updateResult(data) {
		if(data && data[0]){
			resultGameLast = data[0].mid;
			
			if(last_result_id != resultGameLast){
				last_result_id = resultGameLast;
			}
		
			var html = "";
			casino_type = "'teen20'";
			data.forEach((runData) => {
				
				eventId = runData.mid == 0 ? 0 : runData.mid.split(".")[1];
				html += '<span onclick="view_casiono_result('+eventId+','+casino_type+')"  class="last-result ml-1 '+ (runData.result == 1 ? 'playera' : 'playerb') +'">'+(runData.result == 1 ? 'A' : 'B')+'</span>';
			});
			$("#last-result").html(html);
			if(oldGameId == 0 || oldGameId == resultGameLast){	
				$("#card_c1").attr("src", site_url + "storage/front/img/cards/1.png");
				$("#card_c2").attr("src", site_url + "storage/front/img/cards/1.png");
				$("#card_c3").attr("src", site_url + "storage/front/img/cards/1.png");
				$("#card_c4").attr("src", site_url + "storage/front/img/cards/1.png");
				$("#card_c5").attr("src", site_url + "storage/front/img/cards/1.png");
				$("#card_c6").attr("src", site_url + "storage/front/img/cards/1.png");
			}
		}
	}

	function teenpatti(type) {
		gameType = type
		websocket();
	}
	teenpatti("ok");
	jQuery(document).on("click", ".back-1", function () {
		var fullmarketodds = $(this).attr("fullmarketodds");
		if (fullmarketodds != "") {
			side = $(this).attr("side");
			selectionid = $(this).attr("selectionid");
			market_odd_name = $(this).attr("markettype");
			runner = $(this).attr("runner");
			market_runner_name = runner;
			marketname = $(this).attr("marketname");
			markettype = $(this).attr("markettype");
			fullfancymarketrate = $(this).attr("fullfancymarketrate");
			odds_change_value = "disabled";
			runs_lable = 'Runs';
			runs_lable = 'Odds';
			fullfancymarketrate = fullmarketodds;
			eventId = $(this).attr("eventid");
			marketId = $(this).attr("marketid");
			event_name = $(this).attr("event_name");
			$(".select").removeClass("select");
			$(this).addClass("select");
			return_html = "";
			
			$("#inputStake").val();
			$("#market_runner_label").text(market_runner_name);
			$("#bet_stake_side").val("Back");
			$("#odds_val").val(fullmarketodds);
			$("#bet_event_id").val(eventId);
			$("#bet_marketId").val(marketId);
			$("#bet_event_name").val(event_name);
			$("#bet_market_name").val(marketname);
			$("#bet_markettype").val(markettype);
			$("#fullfancymarketrate").val(fullfancymarketrate);
			$("#oddsmarketId").val(marketId);
			$("#market_runner_name").val(market_runner_name);
			$("#market_odd_name").val(market_odd_name);
			
			$('#profitLiability').text('0');
			$(".placeBet").attr('disabled',false);
			$("#inputStake").val("0");
			
			$('.open_back_place_bet').show();
			$('#open_back_place_bet').modal("show");
		}
	});
	
	jQuery(document).on("input", "#inputStake", function () {
	var stake = $("#inputStake").val();
	eventId = $("#fullMarketBetsWrap").attr("eventid");
	$("#inputStake").val(stake);
	odds = parseFloat($("#odds_val").val());
    inputStake = $("#inputStake").val();
    bet_stake_side = $("#bet_stake_side").val();
	bet_markettype = $("#bet_markettype").val();
	if(bet_markettype != "FANCY_ODDS"){
		if(bet_stake_side == "Lay"){
			profit = parseInt(inputStake);
		}else{
			profit = (odds - 1 ) * inputStake;
		}
	}
	$("#profitLiability").text(profit.toFixed(2));
});
jQuery(document).on("click", ".label_stake", function () {
   stake = $(this).attr("stake");
   eventId = $("#fullMarketBetsWrap").attr("eventid");
	$("#inputStake").val(stake);
	odds =  parseFloat($("#odds_val").val());
    inputStake = $("#inputStake").val();
    bet_stake_side = $("#bet_stake_side").val();
	bet_markettype = $("#bet_markettype").val();
	if(bet_markettype != "FANCY_ODDS"){
		if(bet_stake_side == "Lay"){
			profit = (odds - 1 ) * inputStake;
		}else{
			profit = (odds - 1 ) * inputStake;
		}
	}
	$("#profitLiability").text(profit.toFixed(2));
});

jQuery(document).on("click", "#placeBet", function () {
	
	 $("#placeBet").html('<i class="fa fa-spinner  fa-spin"></i> Submit');
	 $(".placeBet").attr('disabled',true);
	 $(".placeBet").removeAttr("id","placeBet");
	 
		var last_place_bet= "";
		bet_stake_side = $("#bet_stake_side").val();
		bet_event_id = $("#bet_event_id").val();
		bet_marketId = $("#bet_marketId").val();
		oddsmarketId = bet_marketId;
		eventType = '2020TEENPATTI';
		bet_event_name = $("#bet_event_name").val();
		inputStake = $("#inputStake").val();
		market_runner_name = $("#market_runner_name").val();
		market_odd_name = $("#market_odd_name").val();
		var runsNo; 
		var oddsNo; 
		bet_market_name = $("#bet_market_name").val();
		eventManualType = 'Auto';
		if(bet_stake_side == "Lay"){
			type = "No";
			class_type = "no";
			unmatched_side_type = false;
		}else{
			type = "Yes";
			class_type = "yes";
			unmatched_side_type = true;
		}
		bet_markettype = $("#bet_markettype").val();
		if(bet_markettype != "FANCY_ODDS"){
			bet_market_type = bet_markettype;
			runsNo = parseFloat($("#odds_val").val());
			oddsNo = parseFloat($("#odds_val").val());
			if(bet_stake_side == "Lay"){
				return_stake = (oddsNo - 1 ) * inputStake;
				return_stake = parseInt(return_stake);
			}else{
				return_stake = (oddsNo - 1 ) * inputStake;
				return_stake = parseInt(return_stake);
			}
		bet_seconds = 1;
		bet_sec = 1000;
		}
		
		/* $("#inputStake").val(""); */
		$(".back-1").removeClass("select");
		$(".lay-1").removeClass("select");
		$("#loadingMsg").show();
		$('.header_Back_'+bet_event_id).remove();
		$('.header_Lay_'+bet_event_id).remove();
		$('#betSlipFullBtn').hide();
		$('#backSlipHeader').hide();
		$('#laySlipHeader').hide();
		$(".back-1").removeClass("select");
		$(".lay-1").removeClass("select");
		
		$("#bet-error-class").removeClass("b-toast-danger");
		$("#bet-error-class").removeClass("b-toast-success");
		setTimeout(function(){ 
			$.ajax({
				 type: 'POST',
				 url: '../ajaxfiles/bet_place_teenpatti.php',
				 dataType: 'json',
				 data: {eventId:bet_event_id,eventType:eventType,marketId:bet_marketId,stack:inputStake,type:type,odds:oddsNo,runs:runsNo,bet_market_type:bet_market_type,oddsmarketId:oddsmarketId,eventManualType:eventManualType,market_runner_name:market_runner_name,market_odd_name:market_odd_name,bet_event_name:bet_event_name},
				 success: function(response) {
					var check_status = response['status'];
					var message = response['message'];
					if(check_status == 'ok'){
							if(bet_markettype != "FANCY_ODDS"){
								oddsNo = runsNo;
							}else{
								oddsNo = oddsNo;
							}
							auth_key = 1;
							$("#bet-error-class").addClass("b-toast-success");
						}else{
							$("#bet-error-class").addClass("b-toast-danger");
						}
						error_message_text = message;
						$("#errorMsgText").text(error_message_text);
						$("#errorMsg").fadeIn('fast').delay(3000).hide(0);
						$(".close-bet-slip").click();
						refresh(markettype);
						$(".placeBet").attr("id","placeBet");
						$("#placeBet").html('Submit');
						
						$(".placeBet").attr('disabled',false);
						
						$('.open_back_place_bet').hide();
						$('#open_back_place_bet').modal("hide");
				 }
			 });
		 }, bet_sec - 2000);
	});
</script>  
<div id="open_back_place_bet" class="modal open_back_place_bet" role="dialog" >
   <div class="modal-dialog">
      <div role="document" id="__BVID__30___BV_modal_content_" tabindex="-1" class="modal-content">
         <header id="__BVID__30___BV_modal_header_" class="modal-header">
            <h5 id="__BVID__30___BV_modal_title_" class="modal-title">Placebet</h5>
            <button type="button" data-dismiss="modal" class="close">&times;</button>                
         </header>
         <div id="__BVID__30___BV_modal_body_" class="modal-body" style="    padding: 0px;">
            <div class="place-bet pt-2 pb-2 back">
               <div class="container-fluid container-fluid-5">
                  <div class="row row5">
                     <div class="col-5"><b id="market_runner_label">Player A</b></div>
                     <div class="col-7 text-right">
                        <div class="float-right">                                        
                        <button class="stakeactionminus btn disabled">
                        	<span class="fa fa-minus"></span>
                        </button>                                        
                        <input type="text" placeholder="0" class="stakeinput" id="odds_val">                                        
                        	<button class="stakeactionminus btn disabled">
                        		<span class="fa fa-plus"></span>
                        	</button>                    
<input type='hidden' id='bet_stake_side' value=''/><input type='hidden' id='bet_event_id' value=''/><input type='hidden' id='bet_marketId' value=''/><input type='hidden' id='bet_event_name' value=''/><input type='hidden' id='bet_market_name' value=''/><input type='hidden' id='bet_markettype' value=''/><input type='hidden' id='fullfancymarketrate' value=''/> <input type='hidden' id='oddsmarketId' value=''/><input type='hidden' id='market_runner_name' value=''/><input type='hidden' id='market_odd_name' value=''/> 
							</div>
                     </div>
                  </div>
                  <div class="row row5 mt-2">
                     <div class="col-4">                                    
                     	<input type="number" placeholder="00" id="inputStake" class="stakeinput w-100">                                
                     </div>
                     <div class="col-4">
                        <button class="btn btn-primary btn-block  placeBet" id="placeBet">
                           <!---->Submit                                    
                        </button>
                     </div>
                     <div class="col-4 text-center pt-1"><span id="profitLiability">0</span></div>
                  </div>
                  <div class="row row5 mt-2">
                     <?php										
                     	$get_button_value = $conn->query("select * from user_master where id=$user_id and (button_value <> '' and button_value IS NOT NULL)");					
                     	$num_rows = $get_button_value->num_rows;					
                     	$button_array = array();					
                     	if($num_rows <= 0){						
                     		$button_array[] = 500;						
                     		$button_array[] = 1000;						
                     		$button_array[] = 2000;						
                     		$button_array[] = 3000;						
                     		$button_array[] = 4000;						
                     		$button_array[] = 5000;						
                     		$button_array[] = 10000;						
                     		$button_array[] = 20000;					
                     	}else{						
                     		$fetch_button_value_data = mysqli_fetch_assoc($get_button_value);						
                     		$fetch_button_value = $fetch_button_value_data['button_value'];						
                     		$default_stake = $fetch_button_value_data['default_stake'];						
                     		$one_bet_default_stake = $fetch_button_value_data['one_bet_default_stake'];						
                     		$button_array = explode(",",$fetch_button_value);					}										
                     		foreach($button_array as $button_value){				
                     ?>														
                    	 		<div class="col-4">                                   
                    	 			<button type="button" class="btn btn-secondary btn-block mb-2 label_stake" stake='<?php echo $button_value; ?>'>                                       
                    	 				<?php echo $button_value; ?>                                    
                    	 			</button>                                
                    	 		</div>
                     <?php					
                     		}				
                     ?>								                                                            
                  </div>
               </div>
            </div>
         </div>
         <!---->            
      </div>
   </div>
</div>
<div id="errorMsg" class="b-toaster b-toaster-top-center" style="display:none;">
<div class="b-toaster-slot vue-portal-target">
    <div role="alert" aria-live="assertive" aria-atomic="true" id="bet-error-class" class="b-toast b-toast-solid b-toast-prepend b-toast-danger">
        <div tabindex="0"  class="toast">
            <header class="toast-header"><strong class="mr-2" id="errorMsgText"></strong>
                
            </header>
            <div class="toast-body"> </div>
        </div>
    </div>
</div>
</div>
<?php
	include "footer.php";
	include "footer-result-popup.php";
?>
</html>