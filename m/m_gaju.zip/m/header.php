<?php

$user_id = $_SESSION['CLIENT_LOGIN_ID'];
$maintenance_sql = 'SELECT * FROM `site_under_maintenance` LIMIT 1';
$maintenance_result = mysqli_query($conn, $maintenance_sql);
$row = mysqli_fetch_array($maintenance_result, MYSQLI_ASSOC);

if ($row['site_status'] == 1 and $user_id != 4) {
    
	echo "<script>location.href='maintenance.html'</script>";
	
}
?>
<style>
	.dropdown-toggle::after {
		content : unset !important;
	}
	#headerMenu2{
		font-size: 14px !important;
	}
</style>
<header class="header">
    <div class="container-fluid">
        <div class="row row5 pb-1">
            <div class="logo col-6  pt-1">
            	<a href="home" class="router-link-exact-active router-link-active">
            		<i class="fas fa-home mr-1"></i> 
            		<img src="../storage/logo.png" alt="Exchange" class="img-fluid logo">
            	</a>
            </div>
            <div class="col-6 text-right bal-expo">
                <p class="mb-0">
					<span>Balance:</span>
                	<!--<i class="fas fa-landmark mr-1"></i>-->
                	<b id="betCredit"> 0 </b>
                </p>
				<div class="">
					<span class="mr-1">
						<span id="btn_exposure_popup"><b id="betExposure">Exp:0</b></span>
					</span>
					<div class="dropdown d-inline-block">
						<a id="headerMenu2" href="#" data-toggle="dropdown" class=" dropdown-toggle">
							<b>								
								<?php
									$user_name_details = $conn->query("select * from user_login_master where UserId=$user_id");										
									$fetch_user_name_details = mysqli_fetch_assoc($user_name_details);										
									$_SESSION['userName'] = $fetch_user_name_details['Email_ID'];										
									echo $_SESSION['userName'];								
								?>		
														
							</b>
							<i class="fas fa-chevron-down ms-1"></i>
						</a>
						<div class="dropdown-menu headerMenu12">
							<!-- <a href="home" class="dropdown-item router-link-exact-active router-link-active">
								Home
							</a> -->
							<a href="accountstatement" class="dropdown-item">
								Account Statement
							</a>
							<a href="current-bet" class="dropdown-item">
								Current Bet
							</a> 
							<?
                                if($user_id  != LOGINDEMOID){
                                    ?>
							<a href="activity_log" class="dropdown-item">
								Activity Logs
							</a> 
							<?
                                }
                                ?>
							<a href="casinoresults" class="dropdown-item">
								 Casino Results
							</a> 
							<?
                                if($user_id  != LOGINDEMOID){
                                    ?>
							<a href="javascript:void(0)" class="dropdown-item">
							Live Casino Bets
							</a> 
							<?
                                }
                                ?>
							<a class="dropdown-item"  data-target="#set_btn_value" data-toggle="modal">
								Set Button Values
							</a>
							<?
                                if($user_id  != LOGINDEMOID){
                                    ?>
							<a href="javascript:void(0)" class="dropdown-item">
							Security Auth Verification
							</a> 
							
							 <a href="changepassword" class="dropdown-item">
								Change Password
							</a> 
							<?
                                }
                                ?>
								<a class="dropdown-item"  data-target="#rulesmenu" data-toggle="modal">
								Rules
							</a> 
							<!--  <a href="profitloss" class="dropdown-item">
								Profit Loss Report
							</a> 
							
							<a href="unsetteledbet" class="dropdown-item">
								Unsetteled Bet
							</a> -->
							 
							
							
							<a href="#" class="dropdown-item" >
								Balance
								<div class="custom-control custom-checkbox float-right"><input type="checkbox" id="customCheck" onclick="balance_checkbox()" checked class="custom-control-input" name="balance_checkbox"> <label for="customCheck" class="custom-control-label"></label></div>
							</a> 
							<a href="#" class="dropdown-item">
								Exposure
								<div class="custom-control custom-checkbox float-right"><input type="checkbox" id="customCheck1" checked class="custom-control-input" name="balance_exposure" onclick="balance_exposure()"> <label for="customCheck1" class="custom-control-label"></label></div>
							</a> 
							<hr style="margin: .5rem 0;">
							<a href="logout" class="dropdown-item mt-2">
								SignOut
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row row5 header-bottom">
			<div class="col-12">
				<div class="search-box-container">
					<div class="search-box1 float-left">
						<input id="searchHeader1" type="text" class="search_input" placeholder="search here..">
						<a id="searchHeader" href="javascript:void(0)" class="search_icon"><i id="searchB" style="font-size:24px;" class="fas fa-search-plus"></i></a>
					</div>
				</div>
				<marquee scrollamount="3" class="searchClose">
				<?php echo SITE_MARQUEE; ?>
				</marquee>
			</div>
		</div>
		
		<?php if ((IPL_EVENT_ID != '' || ELECTION_EVENT_ID != '') && 1!=1){ ?>
			<div class="row header-b-menu">
				<?php if (IPL_EVENT_ID != ''){ ?>
					<div class="col ipl">
						<a href="/m/event_full_market?eventType=<?php echo IPL_EVENT_TYPE_ID;?>&eventId=<?php echo IPL_EVENT_ID;?>&marketId=<?php echo IPL_MARKET_ID;?>" class="text-link"><?php echo IPL_MARKET_NAME;?></a>
					</div>
				<?php } ?>
				<?php if (ELECTION_EVENT_ID != ''){ ?>
					<div class="col election">
						<a href="/m/event_full_market?eventType=<?php echo ELECTION_EVENT_TYPE_ID;?>&eventId=<?php echo ELECTION_EVENT_ID;?>&marketId=<?php echo ELECTION_MARKET_ID;?>" class="text-link"><?php echo ELECTION_MARKET_NAME;?></a>
					</div>
				<?php } ?>
			</div>
		<?php } ?>
	</div>
</header>
<div class="loader" ><i class="fa fa-spinner fa-spin" style="font-size: 38px;"></i></div>
<div class="stop-site" style="display:none;"><div><p>Due to some inactivity or security reasons stop your website, please close the developer tool.</p> <p>Thank you for your support</p></div></div>
<?
            $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);  
            ?>
            <script>
            var curPageName = '<?php echo $curPageName; ?>';  
            </script>
